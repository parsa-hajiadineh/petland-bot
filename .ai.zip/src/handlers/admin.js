const prisma = require("../database/prisma");
const { ORDER_WITH_ITEMS_SELECT } = require("../database/selects");
const bale = require("../bot/bale");
const { reply, notify, replyPhoto } = require("../bot/messenger");
const partnerNotify = require("../services/partnerNotify");
const { formatPrice } = require("../utils/price");
const {
  BTN,
  adminMenu,
  warehouseAdminMenu,
  mainMenu,
  adminInvoiceKindMenu,
  adminProformaMenu,
  adminInvoicesMenu,
  adminBackMenu,
  adminOrderActions,
  adminApprovedActions,
  inlineKb,
  kb,
} = require("../keyboards/menus");
const { buildInvoiceText } = require("../utils/invoice");
const { statusLabel, isWholesaleProformaHold, readWholesaleKind, wholesaleKindLabel } = require("../utils/order");
const { isWarehouseOnly } = require("../services/user");
const { notifyOrderStatus, handleProformaCardText, handleProformaRejectText, handleProformaCallback } = require("./order");
const { getOrCreateWallet } = require("./wallet");
const adminServices = require("./adminServices");
const adminCreditSettings = require("./adminCreditSettings");
const adminManage = require("./adminManage");
const adminBroadcast = require("./adminBroadcast");
const adminProducts = require("./adminProducts");
const salesStats = require("../services/salesStats");

const INV_KIND_PREFIX = "INVKIND:";

function readInvKind(user) {
  const raw = String(user.tempDescription || "");
  if (raw.startsWith(INV_KIND_PREFIX)) return raw.slice(INV_KIND_PREFIX.length);
  return null;
}

function invKindWhere(kind) {
  if (kind === "maneli") return { user: { role: "MANELI" } };
  if (kind === "colleague") {
    return { isWholesale: true, user: { role: { not: "MANELI" } } };
  }
  return { isWholesale: false, user: { role: { not: "MANELI" } } };
}

function invKindTitle(kind) {
  if (kind === "maneli") return "بازاریابان مانلی";
  if (kind === "colleague") return "خرید همکار";
  return "خرید عادی";
}

async function setInvKind(user, kind) {
  const value = `${INV_KIND_PREFIX}${kind}`;
  await prisma.user.update({
    where: { id: user.id },
    data: {
      adminStep: "ADMIN_INVOICES",
      pendingOrderId: null,
      tempDescription: value,
    },
  });
  user.adminStep = "ADMIN_INVOICES";
  user.pendingOrderId = null;
  user.tempDescription = value;
}

async function showSalesStats(user, chatId) {
  try {
    const currentYM = salesStats.toYearMonth(new Date());
    const months = salesStats.lastMonths(12);
    const rows = [];
    for (let i = 0; i < months.length; i += 2) {
      const a = months[i];
      const b = months[i + 1];
      const row = [
        {
          text: a === currentYM
            ? `📊 ${salesStats.formatMonthLabel(a)} (جاری)`
            : `📅 ${salesStats.formatMonthLabel(a)}`,
          callback_data: `stats:${a}:live`,
        },
      ];
      if (b) {
        row.push({
          text: b === currentYM
            ? `📊 ${salesStats.formatMonthLabel(b)} (جاری)`
            : `📅 ${salesStats.formatMonthLabel(b)}`,
          callback_data: `stats:${b}:live`,
        });
      }
      rows.push(row);
    }

    await reply(
      user,
      chatId,
      "📊 آمار فروش\n\nماه مورد نظر را انتخاب کنید (۱۲ ماه اخیر، به‌روز):",
      adminBackMenu()
    );
    await bale.sendKeyboard(chatId, "ماه مورد نظر را انتخاب کنید:", inlineKb(rows));
  } catch (err) {
    console.error("SALES STATS:", err);
    await reply(user, chatId, "خواندن آمار فروش ممکن نشد.", adminBackMenu());
  }
}

module.exports.showMonthStats = async function showMonthStats(user, chatId, yearMonth) {
  try {
    const currentYM = salesStats.toYearMonth(new Date());
    const stats = await salesStats.calcMonthStats(yearMonth);
    const text = salesStats.formatMonthReport(
      yearMonth,
      stats,
      yearMonth === currentYM
    );
    await reply(user, chatId, text, adminBackMenu());
  } catch (err) {
    console.error("MONTH STATS:", err);
    await reply(user, chatId, "خواندن آمار این ماه ممکن نشد.", adminBackMenu());
  }
};

async function showInvoiceKindMenu(user, chatId) {
  await prisma.user.update({
    where: { id: user.id },
    data: {
      adminStep: "ADMIN_INV_KIND",
      pendingOrderId: null,
      tempDescription: null,
    },
  });
  user.adminStep = "ADMIN_INV_KIND";
  user.pendingOrderId = null;
  user.tempDescription = null;
  await reply(
    user,
    chatId,
    "🧾 سفارش‌های مشتریان\n\nنوع فاکتور یا پیش‌فاکتور را انتخاب کنید:",
    adminInvoiceKindMenu()
  );
}

function invoiceRejectedWhere() {
  return {
    status: "REJECTED",
    OR: [{ isWholesale: false }, { receiptImage: { not: null } }],
  };
}

const PF_LIST = {
  wait: {
    step: "ADMIN_PF_WAIT",
    title: "⏳ پیش فاکتورهای در انتظار",
    more: "pfwait_more",
    where: {
      isWholesale: true,
      status: "WAITING_PAYMENT",
      receiptImage: null,
      NOT: { shipmentInfo: { startsWith: "@@CARD@@" } },
    },
  },
  ok: {
    step: "ADMIN_PF_OK",
    title: "✅ پیش فاکتورهای تایید شده",
    more: "pfok_more",
    where: {
      isWholesale: true,
      status: "WAITING_PAYMENT",
      receiptImage: null,
      shipmentInfo: { startsWith: "@@CARD@@" },
    },
  },
  no: {
    step: "ADMIN_PF_NO",
    title: "❌ پیش فاکتورهای رد شده",
    more: "pfno_more",
    where: {
      isWholesale: true,
      status: "REJECTED",
      receiptImage: null,
    },
  },
};

async function showProformaHub(user, chatId) {
  await prisma.user.update({
    where: { id: user.id },
    data: { adminStep: "ADMIN_PROFORMA", pendingOrderId: null },
  });
  user.adminStep = "ADMIN_PROFORMA";
  user.pendingOrderId = null;
  await reply(
    user,
    chatId,
    "📋 پیش فاکتورها\nهمکار و بازاریابان مانلی",
    adminProformaMenu()
  );
}

async function showProformaList(user, chatId, kind, offset = 0) {
  const spec = PF_LIST[kind];
  if (!spec) {
    await showProformaHub(user, chatId);
    return;
  }
  await require("../services/proformaCleanup").expireApprovedProformas();
  await showOrdersInline(
    user,
    chatId,
    spec.where,
    spec.title,
    spec.more,
    offset,
    spec.step,
    { skipKind: true }
  );
}

async function replayProformaList(user, chatId, step) {
  if (step === "ADMIN_PF_WAIT") return showProformaList(user, chatId, "wait");
  if (step === "ADMIN_PF_OK") return showProformaList(user, chatId, "ok");
  if (step === "ADMIN_PF_NO") return showProformaList(user, chatId, "no");
  await showProformaHub(user, chatId);
}

async function showInvoicesMenu(user, chatId) {
  const kind = readInvKind(user);
  if (!kind) {
    await showInvoiceKindMenu(user, chatId);
    return;
  }
  await prisma.user.update({
    where: { id: user.id },
    data: {
      adminStep: "ADMIN_INVOICES",
      pendingOrderId: null,
      tempDescription: `${INV_KIND_PREFIX}${kind}`,
    },
  });
  user.adminStep = "ADMIN_INVOICES";
  user.pendingOrderId = null;
  await reply(
    user,
    chatId,
    `🧾 سفارش‌های مشتریان\nنوع: ${invKindTitle(kind)}`,
    adminInvoicesMenu()
  );
}

async function replayInvoiceList(user, chatId, step) {
  if (step === "ADMIN_PENDING") {
    await showOrdersInline(user, chatId, { status: "WAITING_APPROVAL" }, "🧾 فاکتورهای در انتظار تایید", null, 0, "ADMIN_PENDING");
    return;
  }
  if (step === "ADMIN_APPROVED") {
    await showOrdersInline(user, chatId, { status: { in: ["APPROVED", "PACKAGING"] } }, "✅ فاکتورهای تایید شده", null, 0, "ADMIN_APPROVED");
    return;
  }
  if (step === "ADMIN_REJECTED") {
    await showOrdersInline(user, chatId, invoiceRejectedWhere(), "❌ فاکتورهای رد شده", "rej_more", 0, "ADMIN_REJECTED");
    return;
  }
  if (step === "ADMIN_SHIPPED") {
    await showOrdersInline(user, chatId, { status: "SHIPPED" }, "🚚 فاکتورهای ارسال شده", "shipd_more", 0, "ADMIN_SHIPPED");
    return;
  }
  await showInvoicesMenu(user, chatId);
}

async function goAdminBack(user, chatId) {
  const step = user.adminStep || "";

  if (step === "PROFORMA_CARD" || step === "PROFORMA_REJECT") {
    await showProformaHub(user, chatId);
    return true;
  }

  if (step === "REJECT_REASON" && user.pendingOrderId) {
    const order = await prisma.order.findUnique({
      where: { id: user.pendingOrderId },
      select: ORDER_WITH_ITEMS_SELECT,
    });
    await prisma.user.update({
      where: { id: user.id },
      data: { adminStep: "ADMIN_PENDING" },
    });
    user.adminStep = "ADMIN_PENDING";
    if (order) await showAdminOrderDetail(user, chatId, order);
    else await replayInvoiceList(user, chatId, "ADMIN_PENDING");
    return true;
  }

  if ((step === "SHIP_SNAPP" || step === "SHIP_POST" || step === "SHIP_INFO") && user.pendingOrderId) {
    const order = await prisma.order.findUnique({
      where: { id: user.pendingOrderId },
      select: ORDER_WITH_ITEMS_SELECT,
    });
    await prisma.user.update({
      where: { id: user.id },
      data: { adminStep: "ADMIN_APPROVED" },
    });
    user.adminStep = "ADMIN_APPROVED";
    if (order) await showAdminOrderDetail(user, chatId, order);
    else await replayInvoiceList(user, chatId, "ADMIN_APPROVED");
    return true;
  }

  if (step.startsWith("REPLY_TICKET:")) {
    await prisma.user.update({
      where: { id: user.id },
      data: { adminStep: "ADMIN_TICKETS" },
    });
    const support = require("./support");
    await support.adminListTickets(user, chatId);
    return true;
  }

  if (
    user.pendingOrderId &&
    ["ADMIN_PF_WAIT", "ADMIN_PF_OK", "ADMIN_PF_NO"].includes(step)
  ) {
    await prisma.user.update({
      where: { id: user.id },
      data: { pendingOrderId: null },
    });
    user.pendingOrderId = null;
    await replayProformaList(user, chatId, step);
    return true;
  }

  if (["ADMIN_PF_WAIT", "ADMIN_PF_OK", "ADMIN_PF_NO"].includes(step)) {
    await showProformaHub(user, chatId);
    return true;
  }

  if (step === "ADMIN_PROFORMA") {
    await showInvoiceKindMenu(user, chatId);
    return true;
  }

  if (user.pendingOrderId && ["ADMIN_PENDING", "ADMIN_APPROVED", "ADMIN_REJECTED", "ADMIN_SHIPPED"].includes(step)) {
    await prisma.user.update({
      where: { id: user.id },
      data: { pendingOrderId: null },
    });
    user.pendingOrderId = null;
    await replayInvoiceList(user, chatId, step);
    return true;
  }

  if (["ADMIN_PENDING", "ADMIN_APPROVED", "ADMIN_REJECTED", "ADMIN_SHIPPED"].includes(step)) {
    await showInvoicesMenu(user, chatId);
    return true;
  }

  if (step === "ADMIN_INVOICES") {
    await showInvoiceKindMenu(user, chatId);
    return true;
  }

  if (
    step === "ADMIN_TICKET_OPEN" ||
    step === "ADMIN_TICKET_ANSWERED" ||
    step === "ADMIN_TICKET_SEARCH"
  ) {
    await prisma.user.update({
      where: { id: user.id },
      data: { adminStep: "ADMIN_TICKETS" },
    });
    const support = require("./support");
    await support.adminListTickets(user, chatId);
    return true;
  }

  if (step === "CONFIRM_WITHDRAWAL" || step.startsWith("CONFIRM_WITHDRAWAL:")) {
    await prisma.user.update({
      where: { id: user.id },
      data: { adminStep: "ADMIN_WITHDRAWALS" },
    });
    await showPendingWithdrawals(user, chatId);
    return true;
  }

  if (
    step === "ADMIN_PRODUCTS" ||
    step === "ADMIN_SALES" ||
    step === "ADMIN_WITHDRAWALS" ||
    step === "ADMIN_TICKETS" ||
    step === "ADMIN_INV_KIND" ||
    step === "SVC:LIST" ||
    step === "SINV:HUB" ||
    step === "CRSET:LIST" ||
    step === "MGR:HUB"
  ) {
    await module.exports.showAdminPanel(user, chatId);
    return true;
  }

  if (await adminServices.goBack(user, chatId)) return true;
  if (await adminCreditSettings.goBack(user, chatId)) return true;
  if (await adminBroadcast.goBack(user, chatId)) return true;
  if (await adminProducts.goBack(user, chatId)) return true;
  if (await adminManage.goBack(user, chatId)) return true;

  await prisma.user.update({
    where: { id: user.id },
    data: { adminStep: null, pendingOrderId: null },
  });
  await module.exports.showAdminPanel(user, chatId);
  return true;
}

async function replyProductAdmin(user, chatId) {
  await adminProducts.showHub(user, chatId);
}

module.exports.showAdminPanel = async function showAdminPanel(user, chatId) {
  await prisma.user.update({
    where: { id: user.id },
    data: { adminStep: null, pendingOrderId: null },
  });
  user.adminStep = null;
  user.pendingOrderId = null;
  if (isWarehouseOnly(user)) {
    await reply(user, chatId, "⚙️ پنل ادمین", warehouseAdminMenu());
    return;
  }
  await reply(user, chatId, "⚙️ پنل ادمین", adminMenu());
};

async function showOrdersInline(user, chatId, where, title, morePrefix = null, offset = 0, listStep = null, options = {}) {
  const take = 10;
  const paginated = !!morePrefix;

  if (listStep) {
    await prisma.user.update({
      where: { id: user.id },
      data: { adminStep: listStep, pendingOrderId: null },
    });
    user.adminStep = listStep;
    user.pendingOrderId = null;
  }

  let orders;
  try {
    const kind = options.skipKind ? null : readInvKind(user);
    const kindFilter = kind ? invKindWhere(kind) : {};
    orders = await prisma.order.findMany({
      where: {
        ...where,
        ...kindFilter,
        trackingCode: { startsWith: "PL-" },
      },
      orderBy: { createdAt: "desc" },
      skip: offset,
      take: paginated ? take + 1 : 50,
      select: {
        id: true,
        trackingCode: true,
        totalAmount: true,
        shipmentInfo: true,
        user: { select: { fullName: true, baleId: true, role: true } },
      },
    });
  } catch (err) {
    console.error("ADMIN ORDERS LIST:", err);
    await reply(user, chatId, "خواندن فاکتورها ممکن نشد.", adminBackMenu());
    return;
  }

  if (!orders.length) {
    const msg = offset > 0 ? "فاکتور دیگری وجود ندارد." : `${title}\n\nموردی وجود ندارد.`;
    await reply(user, chatId, msg, adminBackMenu());
    return;
  }

  const shown = paginated ? orders.slice(0, take) : orders;
  const hasMore = paginated && orders.length > take;

  const rows = shown.map((o) => [{
    text: options.skipKind
      ? `🔖 ${o.trackingCode} | ${readWholesaleKind(o) === "maneli" ? "مانلی" : "همکار"} | 💰 ${o.totalAmount.toLocaleString("fa-IR")} تومان`
      : `👤 ${o.user?.fullName || o.user?.baleId} | 💰 ${o.totalAmount.toLocaleString("fa-IR")} تومان`,
    callback_data: `ordr:${o.id}`,
  }]);

  if (hasMore) {
    rows.push([{ text: "⬅️ ۱۰ فاکتور قدیمی‌تر", callback_data: `${morePrefix}:${offset + take}` }]);
  }

  const kind = options.skipKind ? null : readInvKind(user);
  const kindNote = kind ? ` — ${invKindTitle(kind)}` : "";
  const pageInfo = paginated && offset > 0 ? ` — صفحه ${Math.floor(offset / take) + 1}` : "";
  await reply(user, chatId, `${title}${kindNote}${pageInfo}`, adminBackMenu());
  const result = await bale.sendKeyboard(
    chatId,
    "روی فاکتور کلیک کنید:",
    inlineKb(rows)
  );
  const msgId = result?.result?.message_id;
  if (msgId) {
    await prisma.user.update({
      where: { id: user.id },
      data: { lastMessageId: msgId },
    });
  }
}

module.exports.handleAdmin = async function handleAdmin(user, chatId, text) {
  if (text === BTN.ADMIN_PANEL) {
    await module.exports.showAdminPanel(user, chatId);
    return true;
  }

  if (text === BTN.ADMIN_INVOICES || text === BTN.WAREHOUSE_ORDERS) {
    await showInvoiceKindMenu(user, chatId);
    return true;
  }

  if (text === BTN.INV_RETAIL) {
    await setInvKind(user, "retail");
    await showInvoicesMenu(user, chatId);
    return true;
  }
  if (
    text === BTN.INV_COLLEAGUE ||
    (user.adminStep === "ADMIN_INV_KIND" && text === BTN.COLLEAGUE)
  ) {
    await setInvKind(user, "colleague");
    await showInvoicesMenu(user, chatId);
    return true;
  }
  if (text === BTN.INV_MANELI) {
    await setInvKind(user, "maneli");
    await showInvoicesMenu(user, chatId);
    return true;
  }
  if (text === BTN.ADMIN_PROFORMAS) {
    await showProformaHub(user, chatId);
    return true;
  }
  if (text === BTN.ADMIN_PF_WAIT) {
    await showProformaList(user, chatId, "wait");
    return true;
  }
  if (text === BTN.ADMIN_PF_OK) {
    await showProformaList(user, chatId, "ok");
    return true;
  }
  if (text === BTN.ADMIN_PF_NO) {
    await showProformaList(user, chatId, "no");
    return true;
  }

  const shoppingStep = user.orderStep || "";
  if (
    shoppingStep === "PRODUCT_QTY" ||
    shoppingStep === "CART_EDIT_QTY" ||
    shoppingStep === "SEARCH" ||
    shoppingStep === "ADDR_CONFIRM" ||
    shoppingStep === "UPLOAD_RECEIPT" ||
    shoppingStep === "TICKET_MESSAGE" ||
    shoppingStep.startsWith("CHECKOUT") ||
    shoppingStep.startsWith("CAT:")
  ) {
    if (!Object.values(BTN).includes(text)) return false;
  }

  if (user.adminStep === "PROFORMA_CARD" && user.pendingOrderId) {
    if (text === BTN.BACK_PRODUCT_LIST) {
      await goAdminBack(user, chatId);
      return true;
    }
    return handleProformaCardText(user, chatId, text);
  }
  if (user.adminStep === "PROFORMA_REJECT" && user.pendingOrderId) {
    if (text === BTN.BACK_PRODUCT_LIST) {
      await goAdminBack(user, chatId);
      return true;
    }
    return handleProformaRejectText(user, chatId, text);
  }

  if (await adminServices.handleText(user, chatId, text)) return true;

  if (!isWarehouseOnly(user)) {
    if (await adminCreditSettings.handleText(user, chatId, text)) return true;
    if (await adminManage.handleText(user, chatId, text)) return true;
    if (await adminBroadcast.handleText(user, chatId, text)) return true;
    if (await adminProducts.handleText(user, chatId, text)) return true;
  }

  if (text === BTN.BACK_PRODUCT_LIST && (user.adminStep || user.pendingOrderId)) {
    await goAdminBack(user, chatId);
    return true;
  }

  if (text === BTN.APPROVE && user.pendingOrderId) {
    const pending = await prisma.order.findUnique({
      where: { id: user.pendingOrderId },
      select: ORDER_WITH_ITEMS_SELECT,
    }).catch(() => null);
    if (pending && isWholesaleProformaHold(pending)) {
      await handleProformaCallback(user, chatId, `pf:ok:${pending.id}`);
      return true;
    }
    await approveOrder(user, chatId);
    return true;
  }

  if (text === BTN.REJECT && user.pendingOrderId) {
    const pending = await prisma.order.findUnique({
      where: { id: user.pendingOrderId },
      select: ORDER_WITH_ITEMS_SELECT,
    }).catch(() => null);
    if (pending && isWholesaleProformaHold(pending)) {
      await handleProformaCallback(user, chatId, `pf:no:${pending.id}`);
      return true;
    }
    await prisma.user.update({
      where: { id: user.id },
      data: { adminStep: "REJECT_REASON" },
    });
    user.adminStep = "REJECT_REASON";
    await reply(user, chatId, "دلیل رد فاکتور را بنویسید:", adminBackMenu());
    return true;
  }

  if (text === BTN.PACK && user.pendingOrderId) {
    try {
      const order = await prisma.order.update({
        where: { id: user.pendingOrderId },
        data: { status: "PACKAGING" },
        select: ORDER_WITH_ITEMS_SELECT,
      });
      await notifyOrderStatus(order, "📦 سفارش در حال بسته‌بندی است.");
      await reply(user, chatId, "وضعیت: بسته‌بندی", adminApprovedActions());
    } catch (err) {
      console.error("ADMIN PACK:", err);
      await reply(user, chatId, "ثبت بسته‌بندی ممکن نشد.", adminApprovedActions());
    }
    return true;
  }

  if (text === BTN.SHIP && user.pendingOrderId) {
    await reply(user, chatId, "نوع ارسال را انتخاب کنید:", adminBackMenu());
    await bale.sendKeyboard(
      chatId,
      "اسنپ یا پست را انتخاب کنید:",
      inlineKb([
        [{ text: "🚗 ارسال با اسنپ", callback_data: `ship:snapp:${user.pendingOrderId}` }],
        [{ text: "📦 ارسال با پست", callback_data: `ship:post:${user.pendingOrderId}` }],
      ])
    );
    return true;
  }

  if (text === BTN.ADMIN_PENDING) {
    await showOrdersInline(user, chatId, { status: "WAITING_APPROVAL" }, "🧾 فاکتورهای در انتظار تایید", null, 0, "ADMIN_PENDING");
    return true;
  }

  if (text === BTN.ADMIN_APPROVED) {
    await showOrdersInline(user, chatId, { status: { in: ["APPROVED", "PACKAGING"] } }, "✅ فاکتورهای تایید شده", null, 0, "ADMIN_APPROVED");
    return true;
  }

  if (text === BTN.ADMIN_REJECTED) {
    await showOrdersInline(user, chatId, invoiceRejectedWhere(), "❌ فاکتورهای رد شده", "rej_more", 0, "ADMIN_REJECTED");
    return true;
  }

  if (text === BTN.ADMIN_SHIPPED) {
    await showOrdersInline(user, chatId, { status: "SHIPPED" }, "🚚 فاکتورهای ارسال شده", "shipd_more", 0, "ADMIN_SHIPPED");
    return true;
  }

  if (isWarehouseOnly(user) && (
    text === BTN.ADMIN_WITHDRAWALS ||
    text === BTN.ADMIN_SALES ||
    text === BTN.ADMIN_PRODUCTS ||
    text === BTN.ADMIN_SERVICES ||
    text === BTN.ADMIN_MANAGE ||
    text === BTN.ADMIN_CREDIT_SETTINGS
  )) {
    return false;
  }

  if (text === BTN.ADMIN_WITHDRAWALS) {
    await prisma.user.update({
      where: { id: user.id },
      data: { adminStep: "ADMIN_WITHDRAWALS" },
    });
    user.adminStep = "ADMIN_WITHDRAWALS";
    await showPendingWithdrawals(user, chatId);
    return true;
  }

  if (text === BTN.ADMIN_SALES) {
    await prisma.user.update({
      where: { id: user.id },
      data: { adminStep: "ADMIN_SALES" },
    });
    user.adminStep = "ADMIN_SALES";
    await showSalesStats(user, chatId);
    return true;
  }

  if (text === BTN.ADMIN_TICKETS || text === BTN.WAREHOUSE_TICKETS) {
    await prisma.user.update({
      where: { id: user.id },
      data: { adminStep: "ADMIN_TICKETS" },
    });
    user.adminStep = "ADMIN_TICKETS";
    const support = require("./support");
    await support.adminListTickets(user, chatId);
    return true;
  }

  if (text === BTN.TICKET_OPEN) {
    await prisma.user.update({
      where: { id: user.id },
      data: { adminStep: "ADMIN_TICKET_OPEN" },
    });
    user.adminStep = "ADMIN_TICKET_OPEN";
    const support = require("./support");
    await support.adminOpenTickets(user, chatId);
    return true;
  }

  if (text === BTN.TICKET_ANSWERED) {
    await prisma.user.update({
      where: { id: user.id },
      data: { adminStep: "ADMIN_TICKET_ANSWERED" },
    });
    user.adminStep = "ADMIN_TICKET_ANSWERED";
    const support = require("./support");
    await support.adminAnsweredTickets(user, chatId, 0);
    return true;
  }

  if (text === BTN.TICKET_SEARCH) {
    await prisma.user.update({
      where: { id: user.id },
      data: { adminStep: "ADMIN_TICKET_SEARCH" },
    });
    user.adminStep = "ADMIN_TICKET_SEARCH";
    await reply(
      user,
      chatId,
      "🔍 کد تیکت را وارد کنید.\nمثال: #a1b2c3",
      adminBackMenu()
    );
    return true;
  }

  if (text === BTN.ADMIN_PRODUCTS) {
    await adminProducts.showHub(user, chatId);
    return true;
  }

  if (Object.values(BTN).includes(text)) {
    return false;
  }

  if (user.adminStep === "ADMIN_TICKET_SEARCH") {
    const support = require("./support");
    await support.adminSearchTicket(user, chatId, text);
    return true;
  }

  if (text.match(/^[A-Z]{2,3}-\d{3}\s+(AVAILABLE|UNAVAILABLE)$/i)) {
    const [code, status] = text.trim().split(/\s+/);

    const product = await prisma.product
      .update({
        where: { code: code.toUpperCase() },
        data: { status: status.toUpperCase() },
      })
      .catch(() => null);

    if (!product) {
      await reply(user, chatId, "محصول پیدا نشد.", adminBackMenu());
      return true;
    }

    await reply(
      user,
      chatId,
      `✅ ${product.code} → ${status === "AVAILABLE" ? "موجود" : "ناموجود"}`
    );
    return true;
  }

  if (text.startsWith("#") && user.role === "ADMIN") {
    const parts = text.split("\n");
    const ticketRef = parts[0].replace("#", "").trim();
    const message = parts.slice(1).join("\n").trim();

    if (!message) {
      await reply(user, chatId, "فرمت:\n#کد_تیکت\nمتن پاسخ");
      return true;
    }

    const support = require("./support");
    await support.adminReplyTicket(user, chatId, ticketRef, message);
    return true;
  }

  if (user.adminStep?.startsWith("REPLY_TICKET:")) {
    const ticketId = user.adminStep.split(":").slice(1).join(":");
    const support = require("./support");
    await support.adminReplyTicketDirect(user, chatId, ticketId, text);
    return true;
  }

  let order = null;
  try {
    order = await prisma.order.findUnique({
      where: { trackingCode: text.trim() },
      select: ORDER_WITH_ITEMS_SELECT,
    });
  } catch (err) {
    console.error("ADMIN ORDER LOOKUP SKIP:", err.message);
  }

  if (order && user.role === "ADMIN" && String(order.trackingCode).startsWith("PL-")) {
    await showAdminOrderDetail(user, chatId, order);
    return true;
  }

  if (order && String(order.trackingCode).startsWith("TS-")) {
    order = null;
  }

  if (user.adminStep?.startsWith("CONFIRM_WITHDRAWAL:")) {
    const withdrawalId = user.adminStep.split(":").slice(1).join(":");
    await confirmWithdrawal(user, chatId, withdrawalId, text);
    return true;
  }

  if (user.adminStep === "REJECT_REASON" && user.pendingOrderId) {
    try {
      const orderId = user.pendingOrderId;
      const moved = await prisma.order.updateMany({
        where: {
          id: orderId,
          status: "WAITING_APPROVAL",
        },
        data: {
          status: "REJECTED",
          rejectReason: text,
        },
      });
      if (moved.count !== 1) {
        await reply(
          user,
          chatId,
          "این فاکتور قابل رد نیست یا قبلاً پردازش شده.",
          adminBackMenu()
        );
        return true;
      }
      const order = await prisma.order.findUnique({
        where: { id: orderId },
        select: ORDER_WITH_ITEMS_SELECT,
      });

      await prisma.user.update({
        where: { id: user.id },
        data: { adminStep: "ADMIN_INVOICES", pendingOrderId: null },
      });

      await notifyOrderStatus(order, `❌ فاکتور شما رد شد.\n\nدلیل: ${text}`);
      await reply(user, chatId, "فاکتور رد شد.", adminInvoicesMenu());
    } catch (err) {
      console.error("ADMIN REJECT:", err);
      await reply(user, chatId, "رد فاکتور ممکن نشد.", adminBackMenu());
    }
    return true;
  }

  if (user.adminStep === "SHIP_INFO" && user.pendingOrderId) {
    const order = await claimShipOrder(user.pendingOrderId, text);
    if (!order) {
      await reply(user, chatId, "ارسال ثبت نشد؛ سفارش دیگر قابل ارسال نیست.", adminBackMenu());
      return true;
    }

    await prisma.user.update({
      where: { id: user.id },
      data: { adminStep: "ADMIN_INVOICES", pendingOrderId: null },
    });

    await notifyOrderStatus(order, `🚚 سفارش ارسال شد.\n${text}`);
    await reply(user, chatId, "✅ ارسال ثبت شد.", adminInvoicesMenu());
    return true;
  }

  if (user.adminStep === "SHIP_SNAPP" && user.pendingOrderId) {
    const order = await claimShipOrder(user.pendingOrderId, `اسنپ | ${text}`);
    if (!order) {
      await reply(user, chatId, "ارسال ثبت نشد؛ سفارش دیگر قابل ارسال نیست.", adminBackMenu());
      return true;
    }

    await prisma.user.update({
      where: { id: user.id },
      data: { adminStep: "ADMIN_INVOICES", pendingOrderId: null },
    });

    await notifyOrderStatus(order, `🚗 سفارش شما با اسنپ ارسال شد.\n${text}`);
    await reply(user, chatId, "✅ ارسال با اسنپ ثبت شد.", adminInvoicesMenu());
    return true;
  }

  if (user.adminStep === "SHIP_POST" && user.pendingOrderId) {
    const order = await claimShipOrder(
      user.pendingOrderId,
      `پست | کد پیگیری: ${text}`
    );
    if (!order) {
      await reply(user, chatId, "ارسال ثبت نشد؛ سفارش دیگر قابل ارسال نیست.", adminBackMenu());
      return true;
    }

    await prisma.user.update({
      where: { id: user.id },
      data: { adminStep: "ADMIN_INVOICES", pendingOrderId: null },
    });

    await notifyOrderStatus(order, `📦 سفارش شما با پست ارسال شد.\nکد پیگیری مرسوله: ${text}`);
    await reply(user, chatId, "✅ ارسال با پست ثبت شد.", adminInvoicesMenu());
    return true;
  }

  return false;
};

async function claimShipOrder(orderId, shipmentInfo) {
  const moved = await prisma.order.updateMany({
    where: {
      id: orderId,
      status: { in: ["PACKAGING", "APPROVED"] },
    },
    data: { status: "SHIPPED", shipmentInfo },
  });
  if (moved.count !== 1) return null;
  return prisma.order.findUnique({
    where: { id: orderId },
    select: ORDER_WITH_ITEMS_SELECT,
  });
}

async function attachBuyer(order) {
  if (!order?.userId) return order;
  if (order.user?.role) return order;
  try {
    const buyer = await prisma.user.findUnique({
      where: { id: order.userId },
      select: { role: true, fullName: true, baleId: true },
    });
    return { ...order, user: buyer };
  } catch {
    return order;
  }
}

async function showAdminOrderDetail(user, chatId, order) {
  await prisma.user.update({
    where: { id: user.id },
    data: { pendingOrderId: order.id },
  });

  const withBuyer = await attachBuyer(order);
  const invoice = buildInvoiceText(withBuyer, withBuyer.items);
  let keyboard = adminBackMenu();

  if (isWholesaleProformaHold(order)) {
    await reply(user, chatId, invoice, adminOrderActions());
    return;
  }

  if (order.status === "WAITING_APPROVAL") {
    keyboard = adminOrderActions();

    if (order.receiptImage) {
      await bale.sendPhoto(chatId, order.receiptImage, "📸 رسید پرداخت");
    }

    await reply(user, chatId, invoice, keyboard);
    return;
  }

  if (order.status === "APPROVED" || order.status === "PACKAGING") {
    keyboard = adminApprovedActions();
  }

  await reply(user, chatId, invoice, keyboard);
}

async function approveOrder(user, chatId) {
  const orderId = user.pendingOrderId;
  let order;
  try {
    const moved = await prisma.order.updateMany({
      where: { id: orderId, status: "WAITING_APPROVAL" },
      data: { status: "PACKAGING" },
    });
    if (moved.count !== 1) {
      await reply(
        user,
        chatId,
        "این فاکتور قبلاً تایید شده یا قابل تایید نیست.",
        adminBackMenu()
      );
      return;
    }
    order = await prisma.order.findUnique({
      where: { id: orderId },
      select: ORDER_WITH_ITEMS_SELECT,
    });
  } catch (err) {
    console.error("ADMIN APPROVE:", err);
    await reply(user, chatId, "تایید فاکتور ممکن نشد.", adminOrderActions());
    return;
  }
  if (!order) {
    await reply(user, chatId, "تایید فاکتور ممکن نشد.", adminOrderActions());
    return;
  }

  const buyer = await prisma.user
    .findUnique({
      where: { id: order.userId },
      select: { id: true, role: true, baleId: true, referrerId: true },
    })
    .catch(() => null);
  const isManeli = buyer?.role === "MANELI";

  const credit = isManeli
    ? null
    : await require("../services/goldenCampaign")
        .grantPurchaseCredit(order, user.id, { silent: true })
        .catch((err) => {
          console.error("GOLDEN CREDIT APPROVE SKIP:", err.message);
          return null;
        });
  const creditAmount = Number(credit?.totalCredit || 0);
  const statusMsg =
    creditAmount > 0
      ? `✅ سفارش شما تایید شد و این خرید ${formatPrice(
          creditAmount
        )} اعتبار به کیف پول شما اضافه کرد.`
      : "✅ سفارش شما تایید شد و در حال آماده‌سازی است.";
  await notifyOrderStatus(order, statusMsg);

  const owner = buyer || (await prisma.user.findUnique({
    where: { id: order.userId },
  }));

  if (owner) {
    await partnerNotify.notifyOrderBuyer(
      { ...order, user: owner },
      buildInvoiceText({ ...order, user: owner }, order.items)
    );

    if (
      owner.referrerId &&
      owner.role !== "MANELI" &&
      owner.role !== "COLLEAGUE"
    ) {
      const commission = Math.floor(order.totalAmount * 0.05);
      const referrer = commission
        ? await prisma.user.findUnique({
            where: { id: owner.referrerId },
          })
        : null;
      if (
        commission > 0 &&
        referrer &&
        referrer.role !== "COLLEAGUE" &&
        referrer.role !== "MANELI"
      ) {
        const referrerWallet = await getOrCreateWallet(owner.referrerId);
        const before = Number(referrerWallet?.balance || 0);
        await prisma.wallet.update({
          where: { userId: owner.referrerId },
          data: { balance: { increment: commission } },
        });
        await require("../services/financialAudit").logFinancial({
          actorUserId: user.id,
          action: "COMMISSION",
          entityType: "Order",
          entityId: order.id,
          amount: commission,
          balanceBefore: before,
          balanceAfter: before + commission,
          reason: "referral_commission_5pct",
          detail: { trackingCode: order.trackingCode },
        });
        await notify(
          referrer.baleId,
          `🎉 پورسانت دریافت کردید!\n\n💰 مبلغ: ${commission.toLocaleString("fa-IR")} تومان\n\nاین پورسانت بابت خرید تایید‌شده یکی از معرفی‌شده‌های شما است.\nبرای مشاهده موجودی کیف پول از منوی اصلی وارد شوید.`
        );
      }
    }
  }

  await reply(user, chatId, "✅ فاکتور تایید شد.", adminApprovedActions());
}

module.exports.viewOrderById = async function viewOrderById(user, chatId, orderId) {
  const order = await prisma.order.findUnique({
    where: { id: orderId },
    select: ORDER_WITH_ITEMS_SELECT,
  });
  if (!order || !String(order.trackingCode).startsWith("PL-")) {
    await reply(user, chatId, "فاکتور پیدا نشد.", adminBackMenu());
    return;
  }
  await showAdminOrderDetail(user, chatId, order);
};

module.exports.showRejectedOrders = async function showRejectedOrders(user, chatId, offset) {
  await showOrdersInline(user, chatId, invoiceRejectedWhere(), "❌ فاکتورهای رد شده", "rej_more", offset, "ADMIN_REJECTED");
};

module.exports.showProformaList = showProformaList;
module.exports.showProformaHub = showProformaHub;

module.exports.showShippedOrders = async function showShippedOrders(user, chatId, offset) {
  await showOrdersInline(user, chatId, { status: "SHIPPED" }, "🚚 فاکتورهای ارسال شده", "shipd_more", offset, "ADMIN_SHIPPED");
};

async function showPendingWithdrawals(user, chatId) {
  const withdrawals = await prisma.withdrawal.findMany({
    where: { status: "PENDING" },
    orderBy: { createdAt: "asc" },
    include: { wallet: { include: { user: true } } },
  });

  if (!withdrawals.length) {
    await reply(user, chatId, "💸 درخواست‌های پورسانت\n\nدرخواست برداشت در انتظاری وجود ندارد.", adminBackMenu());
    return;
  }

  const rows = withdrawals.map((w) => [{
    text: `👤 ${w.wallet.user.fullName || w.wallet.user.baleId} | 💰 ${w.amount.toLocaleString("fa-IR")} تومان`,
    callback_data: `wdr:${w.id}`,
  }]);

  await reply(user, chatId, `💸 درخواست‌های پورسانت (${withdrawals.length} مورد)`, adminBackMenu());
  await bale.sendKeyboard(chatId, "روی هر درخواست کلیک کنید:", inlineKb(rows));
}

module.exports.showWithdrawalDetail = async function showWithdrawalDetail(user, chatId, withdrawalId) {
  const w = await prisma.withdrawal.findUnique({
    where: { id: withdrawalId },
    include: { wallet: { include: { user: true } } },
  });

  if (!w) {
    await reply(user, chatId, "درخواست پیدا نشد.", adminBackMenu());
    return;
  }

  const date = new Date(w.createdAt).toLocaleDateString("fa-IR");
  const status = w.status === "PAID" ? "✅ پرداخت شده" : "⏳ در انتظار";

  const detail = [
    "💸 جزئیات درخواست برداشت",
    "━━━━━━━━━━━━━━━━━━",
    `👤 کاربر: ${w.wallet.user.fullName || w.wallet.user.baleId}`,
    `💰 مبلغ: ${w.amount.toLocaleString("fa-IR")} تومان`,
    `💳 شماره کارت: ${w.cardNumber}`,
    `👤 نام صاحب کارت: ${w.cardHolder}`,
    `📅 تاریخ: ${date}`,
    `📊 وضعیت: ${status}`,
  ].join("\n");

  if (w.status === "PAID") {
    await reply(user, chatId, `${detail}\n🔖 کد رهگیری: ${w.trackingCode}`, adminBackMenu());
    return;
  }

  await prisma.user.update({
    where: { id: user.id },
    data: { adminStep: `CONFIRM_WITHDRAWAL:${w.id}` },
  });

  await reply(
    user,
    chatId,
    `${detail}\n\nپس از واریز مبلغ، کد رهگیری تراکنش را وارد کنید:`,
    adminBackMenu()
  );
};

async function confirmWithdrawal(user, chatId, withdrawalId, trackingCode) {
  const w = await prisma.withdrawal.findUnique({
    where: { id: withdrawalId },
    include: { wallet: { include: { user: true } } },
  });

  if (!w || w.status === "PAID") {
    await prisma.user.update({
      where: { id: user.id },
      data: { adminStep: null },
    });
    await reply(user, chatId, "این درخواست قبلاً تایید شده یا پیدا نشد.", adminBackMenu());
    return;
  }

  const moved = await prisma.withdrawal.updateMany({
    where: { id: withdrawalId, status: "PENDING" },
    data: { status: "PAID", trackingCode: trackingCode.trim() },
  });
  if (moved.count !== 1) {
    await prisma.user.update({
      where: { id: user.id },
      data: { adminStep: null },
    });
    await reply(user, chatId, "این درخواست قبلاً تایید شده یا پیدا نشد.", adminBackMenu());
    return;
  }
  await require("../services/financialAudit").logFinancial({
    actorUserId: user.id,
    action: "COMMISSION_WITHDRAW_PAID",
    entityType: "Withdrawal",
    entityId: withdrawalId,
    amount: w.amount,
    reason: "withdrawal_paid",
    detail: { trackingCode: trackingCode.trim() },
  });

  await prisma.user.update({
    where: { id: user.id },
    data: { adminStep: null },
  });

  const recipient = w.wallet.user;
  await notify(
    recipient.baleId,
    `🎉 تبریک! پورسانت شما واریز شد.\n\n💰 مبلغ: ${w.amount.toLocaleString("fa-IR")} تومان\n💳 شماره کارت: ${w.cardNumber}\n🔖 کد رهگیری: ${trackingCode.trim()}\n\nمبلغ با موفقیت به حساب شما واریز گردید.`
  );

  await reply(user, chatId, `✅ تایید شد. کد رهگیری برای کاربر ارسال گردید.`, adminBackMenu());
}

module.exports.handleAdminPhoto = async function handleAdminPhoto(
  user,
  chatId,
  photo
) {
  return adminProducts.handlePhoto(user, chatId, photo);
};
