const prisma = require("../database/prisma");
const { reloadUser } = require("../services/user");
const { isAdmin, isWarehouseOnly } = require("../services/user");
const { BTN, kb, backMain, mainMenu, PRODUCT_CATEGORIES, adminBackMenu } = require("../keyboards/menus");
const { reply } = require("../bot/messenger");
const { MARKETING_ACCESS_CODE } = require("../config");
const { isMother } = require("../bot/context");
const { isWholesaleProformaHold, isProformaPayExpired } = require("../utils/order");
const { parseQty, isDigitsOnly } = require("../utils/digits");
const { MOTHER_STEP, isEditCallback, parseEditCallback } = require("../utils/cartEdit");

const productsHandler = require("./products");
const cartHandler = require("./cart");
const orderHandler = require("./order");
const colleagueHandler = require("./colleague");
const helpHandler = require("./help");
const supportHandler = require("./support");
const adminHandler = require("./admin");
const startHandler = require("./start");
const marketingHandler = require("./marketing");
const walletHandler = require("./wallet");

function isStartText(text) {
  return text === "/start" || text.startsWith("/start ") || text.startsWith("/start@");
}

module.exports = async function messageHandler(message, user) {
  if (!isMother()) {
    try {
      return await require("./tenantShop").handleMessage(message, user);
    } catch (err) {
      console.error("TENANT SHOP:", err);
      await reply(
        user,
        message.chat.id,
        "فروشگاه الان پاسخ نداد. لطفاً دوباره /start بزنید."
      );
      return;
    }
  }

  const text = (message.text || "").trim();
  const chatId = message.chat.id;

  try {
    const fresh = await reloadUser(user.id);
    if (fresh) user = fresh;
  } catch (err) {
    console.error("RELOAD USER SKIP:", err.message);
  }

  if (text === "/myid" || text === "/id") {
    await reply(
      user,
      chatId,
      `آیدی عددی بله شما:\n${user.baleId}`,
      mainMenu(user)
    );
    return;
  }

  if (
    text === BTN.BACK_MAIN ||
    isStartText(text) ||
    text === BTN.BACK_PRODUCTS ||
    text === BTN.PRODUCTS ||
    text === BTN.CATALOG_PDF ||
    text === BTN.CART ||
    text === BTN.SEARCH ||
    text === BTN.HELP ||
    text === BTN.SUPPORT ||
    text === BTN.ORDERS ||
    text === BTN.EDIT_CART ||
    text === BTN.CLEAR_CART ||
    text === BTN.CHECKOUT
  ) {
    await productsHandler.clearProductListMessages(user, chatId);
    if (user.orderStep === MOTHER_STEP) {
      await prisma.user.update({
        where: { id: user.id },
        data: {
          orderStep: null,
          ...(String(user.tempDescription || "").startsWith("CE:")
            ? { tempDescription: null }
            : {}),
        },
      });
      user.orderStep = null;
      if (String(user.tempDescription || "").startsWith("CE:")) {
        user.tempDescription = null;
      }
    }
  }

  if (text === BTN.BACK_MAIN || isStartText(text)) {
    try {
      await prisma.user.update({
        where: { id: user.id },
        data: {
          orderStep: null,
          adminStep: null,
          pendingOrderId: null,
        },
      });
      const fresh = await reloadUser(user.id);
      if (fresh) user = fresh;
    } catch (err) {
      console.error("START RESET SKIP:", err.message);
    }
    await startHandler(user, message);
    return;
  }

  if (user.orderStep === "PRODUCT_QTY" && isDigitsOnly(text)) {
    const qty = parseQty(text);
    if (qty === null) {
      await reply(user, chatId, "لطفاً یک عدد معتبر (1 تا 999) وارد کنید.");
      return;
    }
    await productsHandler.addToCartWithQty(user, chatId, qty);
    return;
  }

  if (user.orderStep === MOTHER_STEP && isDigitsOnly(text)) {
    const qty = parseQty(text, { allowZero: true });
    if (qty === null) {
      await reply(user, chatId, "لطفاً یک عدد معتبر (۰ تا ۹۹۹) وارد کنید.");
      return;
    }
    await cartHandler.applyEditQty(user, chatId, qty);
    return;
  }

  if (text.startsWith("PL-") && user.adminStep === "VIEW_MY_ORDERS") {
    const shown = await orderHandler.showOrderByTracking(user, chatId, text);
    if (!shown) {
      await reply(user, chatId, "❌ سفارشی با این کد پیگیری یافت نشد.\nلطفاً کد را بررسی و دوباره ارسال کنید.");
    }
    return;
  }

  if (await colleagueHandler(user, chatId, text)) return;

  if (isAdmin(user) && (await adminHandler.handleAdmin(user, chatId, text))) {
    return;
  }

  if (await supportHandler.handleSupport(user, chatId, text)) return;

  if (text === BTN.HELP) {
    await helpHandler(user, chatId);
    return;
  }

  if (text === BTN.MARKETING || text === BTN.WALLET) {
    if (user.role === "COLLEAGUE" || user.role === "MANELI" || isWarehouseOnly(user)) {
      await reply(
        user,
        chatId,
        "این بخش در این حالت در دسترس نیست.",
        mainMenu(user)
      );
      return;
    }
    if (text === BTN.MARKETING) {
      await marketingHandler.showMarketing(user, chatId);
      return;
    }
    await walletHandler.showWallet(user, chatId);
    return;
  }

  if (text === BTN.WITHDRAW_NEW) {
    if (user.role === "COLLEAGUE" || user.role === "MANELI" || isWarehouseOnly(user)) {
      await reply(
        user,
        chatId,
        "این بخش در این حالت در دسترس نیست.",
        mainMenu(user)
      );
      return;
    }
    await walletHandler.startWithdrawal(user, chatId);
    return;
  }

  if (text === BTN.WITHDRAW_HISTORY) {
    if (user.role === "COLLEAGUE" || user.role === "MANELI" || isWarehouseOnly(user)) {
      await reply(
        user,
        chatId,
        "این بخش در این حالت در دسترس نیست.",
        mainMenu(user)
      );
      return;
    }
    await walletHandler.showWithdrawalHistory(user, chatId);
    return;
  }

  if (text === BTN.SEARCH) {
    await prisma.user.update({
      where: { id: user.id },
      data: { orderStep: "SEARCH", adminStep: null },
    });
    user.adminStep = null;
    await reply(
      user,
      chatId,
      "🔍 نام، برند، کد یا حتی بخشی از نام محصول را بنویسید:",
      kb([[{ text: BTN.BACK_MAIN }]])
    );
    return;
  }

  if (user.orderStep === "SEARCH") {
    await prisma.user.update({
      where: { id: user.id },
      data: { orderStep: null },
    });
    user = await reloadUser(user.id);
    await productsHandler.handleSearch(user, chatId, text);
    return;
  }

  if (text === BTN.BACK_PRODUCT_LIST) {
    await productsHandler.backToProductList(user, chatId);
    return;
  }

  if (text === BTN.CATALOG_PDF) {
    await productsHandler.showCatalogPdf(user, chatId);
    return;
  }

  if (text === BTN.PRODUCTS || text === BTN.BACK_PRODUCTS) {
    if (user.orderStep && user.orderStep.startsWith("CAT:")) {
      await prisma.user.update({
        where: { id: user.id },
        data: { orderStep: null },
      });
      user = await reloadUser(user.id);
    }
    await productsHandler(user, chatId);
    return;
  }

  if (text === BTN.CART) {
    await cartHandler.showCart(user, chatId);
    return;
  }

  if (text === BTN.CLEAR_CART) {
    await cartHandler.clearCart(user, chatId);
    return;
  }

  if (text === BTN.EDIT_CART) {
    await cartHandler.showEditList(user, chatId, 0);
    return;
  }

  if (text === BTN.CHECKOUT) {
    await orderHandler.startCheckout(user, chatId);
    return;
  }

  if (text === BTN.ORDERS) {
    await prisma.user.update({
      where: { id: user.id },
      data: { orderStep: null, pendingOrderId: null, adminStep: "VIEW_MY_ORDERS" },
    });
    user = await reloadUser(user.id);
    await orderHandler.showMyOrders(user, chatId);
    return;
  }

  if (text === BTN.ADD_CART) {
    await productsHandler.startAddToCart(user, chatId);
    return;
  }

  if (text === BTN.UPLOAD_RECEIPT) {
    let pendingId = user.pendingOrderId;

    if (!pendingId) {
      const pending = await prisma.order.findFirst({
        where: {
          userId: user.id,
          status: "WAITING_PAYMENT",
          trackingCode: { startsWith: "PL-" },
        },
        orderBy: { createdAt: "desc" },
        select: {
          id: true,
          status: true,
          isWholesale: true,
          receiptImage: true,
          shipmentInfo: true,
        },
      });
      if (pending && isProformaPayExpired(pending)) {
        await require("../services/proformaCleanup").closeExpiredProforma(
          { ...pending, userId: user.id },
          false
        );
        await reply(
          user,
          chatId,
          "⏰ اعتبار این پیش‌فاکتور تمام شده است.\nبرای خرید باید دوباره سفارش ثبت کنید.",
          mainMenu(user)
        );
        return;
      }
      if (pending && isWholesaleProformaHold(pending)) {
        await reply(
          user,
          chatId,
          "پیش‌فاکتور در انتظار بررسی ادمین است. بعد از تایید، ادامه پرداخت را از «📦 سفارشات من» انجام دهید."
        );
        return;
      }
      pendingId = pending?.id;
    }

    if (!pendingId) {
      await reply(user, chatId, "سفارشی در انتظار پرداخت ندارید.");
      return;
    }

    const pendingOrder = await prisma.order.findFirst({
      where: { id: pendingId, userId: user.id, trackingCode: { startsWith: "PL-" } },
      select: {
        id: true,
        status: true,
        isWholesale: true,
        receiptImage: true,
        shipmentInfo: true,
      },
    });
    if (pendingOrder && isProformaPayExpired(pendingOrder)) {
      await require("../services/proformaCleanup").closeExpiredProforma(
        { ...pendingOrder, userId: user.id },
        false
      );
      await reply(
        user,
        chatId,
        "⏰ اعتبار این پیش‌فاکتور تمام شده است.\nبرای خرید باید دوباره سفارش ثبت کنید.",
        mainMenu(user)
      );
      return;
    }
    if (pendingOrder && isWholesaleProformaHold(pendingOrder)) {
      await reply(
        user,
        chatId,
        "پیش‌فاکتور در انتظار بررسی ادمین است. بعد از تایید، ادامه پرداخت را از «📦 سفارشات من» انجام دهید."
      );
      return;
    }

    await prisma.user.update({
      where: { id: user.id },
      data: {
        orderStep: "UPLOAD_RECEIPT",
        pendingOrderId: pendingId,
      },
    });
    await reply(user, chatId, "📸 لطفاً اسکرین‌شات رسید پرداخت را ارسال کنید.");
    return;
  }

  if (text.startsWith("PL-") && !isAdmin(user)) {
    const shown = await orderHandler.showOrderByTracking(user, chatId, text);
    if (!shown) {
      await reply(user, chatId, "❌ سفارشی با این کد پیگیری یافت نشد.\nلطفاً کد را بررسی و دوباره ارسال کنید.");
    }
    return;
  }

  if (await walletHandler.handleWithdrawalStep(user, chatId, text)) {
    return;
  }

  if (text === BTN.CONFIRM_ADDRESS) {
    await orderHandler.confirmSavedAddress(user, chatId);
    return;
  }

  if (text === BTN.DELETE_ADDRESS) {
    await orderHandler.deleteSavedAddress(user, chatId);
    return;
  }

  if (await orderHandler.handleCheckoutStep(user, chatId, text)) {
    return;
  }

  const mainCat = PRODUCT_CATEGORIES.find((c) => c.btn === text);
  if (mainCat) {
    await prisma.user.update({
      where: { id: user.id },
      data: { orderStep: `CAT:${mainCat.btn}` },
    });
    await productsHandler.showSubMenu(user, chatId, mainCat.btn);
    return;
  }

  if (user.orderStep && user.orderStep.startsWith("CAT:")) {
    const parentCatBtn = user.orderStep.replace("CAT:", "");
    const parentCat = PRODUCT_CATEGORIES.find((c) => c.btn === parentCatBtn);
    if (parentCat && parentCat.subMenus.includes(text)) {
      await productsHandler.showBrandProducts(user, chatId, parentCatBtn, text);
      return;
    }
  }

  let product = null;
  try {
    product = await productsHandler.loadProductByCode(text.trim().toUpperCase());
  } catch (err) {
    console.error("PRODUCT CODE LOOKUP SKIP:", err.message);
  }

  if (product) {
    await productsHandler.showProduct(user, chatId, product);
    return;
  }

  if (MARKETING_ACCESS_CODE && text.trim() === MARKETING_ACCESS_CODE) {
    if (user.role === "COLLEAGUE" || user.role === "MANELI" || isWarehouseOnly(user)) {
      await reply(
        user,
        chatId,
        "لطفاً از دکمه‌های منو استفاده کنید.\nبرای راهنما: 📖 راهنما"
      );
      return;
    }
    await prisma.user.update({
      where: { id: user.id },
      data: { marketingEnabled: true },
    });
    user = await reloadUser(user.id);
    await reply(
      user,
      chatId,
      "✅ دسترسی به بازاریابی و کیف پول فعال شد.",
      mainMenu(user)
    );
    return;
  }

  await reply(
    user,
    chatId,
    "لطفاً از دکمه‌های منو استفاده کنید.\nبرای راهنما: 📖 راهنما"
  );
};

module.exports.handleCallbackQuery = async function handleCallbackQuery(cq, user) {
  if (!isMother()) {
    try {
      return await require("./tenantShop").handleCallbackQuery(cq, user);
    } catch (err) {
      console.error("TENANT CALLBACK:", err);
      return;
    }
  }

  const data = (cq.data || "").trim();
  const chatId = cq.message.chat.id;

  user = await reloadUser(user.id);

  if (isEditCallback(data)) {
    const parsed = parseEditCallback(data);
    if (parsed?.kind === "item") {
      await cartHandler.startEditItem(user, chatId, parsed.id);
    } else if (parsed?.kind === "more") {
      await cartHandler.showEditList(user, chatId, parsed.offset);
    }
    return;
  }

  if ((data.startsWith("pf:ok:") || data.startsWith("pf:no:")) && isAdmin(user)) {
    await orderHandler.handleProformaCallback(user, chatId, data);
    return;
  }

  if (data.startsWith("prog:")) {
    await colleagueHandler.handleProgrammingCallback(user, chatId, data);
    return;
  }

  if (
    data.startsWith("sb") ||
    data.startsWith("siv:") ||
    data.startsWith("svct:") ||
    data === "svcok"
  ) {
    await colleagueHandler.handleServiceCallback(user, chatId, data);
    return;
  }

  if (data.startsWith("asvc:") && isAdmin(user)) {
    await require("./adminServices").handleCallback(user, chatId, data);
    return;
  }

  if (data.startsWith("sinv:") && isAdmin(user)) {
    await require("./adminServices").handleCallback(user, chatId, data);
    return;
  }

  if (
    (data.startsWith("silp:") || data.startsWith("sila:") || data.startsWith("silr:")) &&
    isAdmin(user)
  ) {
    await require("./adminServices").handleCallback(user, chatId, data);
    return;
  }

  if (
    (data.startsWith("mgru:") ||
      data.startsWith("mgrb:") ||
      data.startsWith("mgrq:") ||
      data.startsWith("mgrk:")) &&
    isAdmin(user)
  ) {
    await require("./adminManage").handleCallback(user, chatId, data);
    return;
  }

  if (
    (data.startsWith("bcsh:") ||
      data.startsWith("bcm:") ||
      data.startsWith("bcu:") ||
      data.startsWith("bcp:") ||
      data.startsWith("bcg:")) &&
    isAdmin(user)
  ) {
    await require("./adminBroadcast").handleCallback(user, chatId, data);
    return;
  }

  if (
    (data.startsWith("apc:") || data.startsWith("apb:")) &&
    isAdmin(user)
  ) {
    await require("./adminProducts").handleCallback(user, chatId, data);
    return;
  }

  if (data.startsWith("PL-")) {
    const shown = await orderHandler.showOrderByTracking(user, chatId, data);
    if (!shown) {
      await reply(user, chatId, "❌ سفارشی با این کد پیگیری یافت نشد.");
    }
    return;
  }

  if (data.startsWith("addr:view:")) {
    const addressId = data.replace("addr:view:", "");
    await orderHandler.handleSavedAddressView(user, chatId, addressId);
    return;
  }

  if (data === "addr:new") {
    await prisma.user.update({
      where: { id: user.id },
      data: { orderStep: "CHECKOUT_NAME", tempAddressId: null },
    });
    await reply(
      user,
      chatId,
      "📝 ثبت سفارش\n\n👤 نام و نام خانوادگی گیرنده را وارد کنید:",
      backMain()
    );
    return;
  }

  if (data === "main:back") {
    await prisma.user.update({
      where: { id: user.id },
      data: { orderStep: null, adminStep: null, pendingOrderId: null },
    });
    user = await reloadUser(user.id);
    await startHandler(user, { chat: { id: chatId } });
    return;
  }

  if (data === "cat:back") {
    await productsHandler(user, chatId);
    return;
  }

  if (data.startsWith("product:")) {
    const code = data.replace("product:", "");
    try {
      const product = await productsHandler.loadProductByCode(code);
      if (product) {
        await productsHandler.showProduct(user, chatId, product);
      } else {
        await reply(user, chatId, "خواندن این محصول ممکن نشد.");
      }
    } catch (err) {
      console.error("PRODUCT CALLBACK:", err);
      await reply(user, chatId, "نمایش این محصول با خطا مواجه شد. لطفاً دوباره تلاش کنید.");
    }
    return;
  }

  if (data.startsWith("tkt:view:") && isAdmin(user)) {
    const ticketId = data.replace("tkt:view:", "");
    const support = require("./support");
    await support.adminShowTicket(user, chatId, ticketId);
    return;
  }

  if (data.startsWith("tkt:more:") && isAdmin(user)) {
    const rest = data.slice("tkt:more:".length);
    const support = require("./support");
    const parts = rest.split(":");
    if (parts[0] === "o") {
      await support.adminOpenTickets(user, chatId, Number(parts[1]) || 0);
    } else if (parts[0] === "a") {
      await support.adminAnsweredTickets(user, chatId, Number(parts[1]) || 0);
    } else {
      await support.adminAnsweredTickets(user, chatId, parseInt(rest, 10) || 0);
    }
    return;
  }

  if (data.startsWith("ordr:") && isAdmin(user)) {
    const orderId = data.replace("ordr:", "");
    await adminHandler.viewOrderById(user, chatId, orderId);
    return;
  }

  if (data.startsWith("wdr:") && isAdmin(user)) {
    const withdrawalId = data.replace("wdr:", "");
    await adminHandler.showWithdrawalDetail(user, chatId, withdrawalId);
    return;
  }

  if (data.startsWith("stats:") && isAdmin(user)) {
    const yearMonth = data.split(":")[1];
    await adminHandler.showMonthStats(user, chatId, yearMonth);
    return;
  }

  if (data.startsWith("pfwait_more:") && isAdmin(user)) {
    const offset = parseInt(data.replace("pfwait_more:", ""), 10) || 0;
    await adminHandler.showProformaList(user, chatId, "wait", offset);
    return;
  }
  if (data.startsWith("pfok_more:") && isAdmin(user)) {
    const offset = parseInt(data.replace("pfok_more:", ""), 10) || 0;
    await adminHandler.showProformaList(user, chatId, "ok", offset);
    return;
  }
  if (data.startsWith("pfno_more:") && isAdmin(user)) {
    const offset = parseInt(data.replace("pfno_more:", ""), 10) || 0;
    await adminHandler.showProformaList(user, chatId, "no", offset);
    return;
  }

  if (data.startsWith("rej_more:") && isAdmin(user)) {
    const offset = parseInt(data.replace("rej_more:", ""), 10) || 0;
    await adminHandler.showRejectedOrders(user, chatId, offset);
    return;
  }

  if (data.startsWith("shipd_more:") && isAdmin(user)) {
    const offset = parseInt(data.replace("shipd_more:", ""), 10) || 0;
    await adminHandler.showShippedOrders(user, chatId, offset);
    return;
  }

  if (data.startsWith("ship:snapp:") && isAdmin(user)) {
    const orderId = data.replace("ship:snapp:", "");
    await prisma.user.update({
      where: { id: user.id },
      data: { adminStep: "SHIP_SNAPP", pendingOrderId: orderId },
    });
    await reply(user, chatId,
      "🚗 ارسال با اسنپ\n\nاطلاعات را در یک پیام ارسال کنید:\nشماره تماس راننده، پلاک، مدل ماشین",
      adminBackMenu()
    );
    return;
  }

  if (data.startsWith("ship:post:") && isAdmin(user)) {
    const orderId = data.replace("ship:post:", "");
    await prisma.user.update({
      where: { id: user.id },
      data: { adminStep: "SHIP_POST", pendingOrderId: orderId },
    });
    await reply(user, chatId, "📦 ارسال با پست\n\nکد پیگیری مرسوله را وارد کنید:", adminBackMenu());
    return;
  }
};

module.exports.handlePhoto = async function handlePhoto(message, user) {
  if (!isMother()) {
    try {
      return await require("./tenantShop").handlePhoto(message, user);
    } catch (err) {
      console.error("TENANT PHOTO:", err);
      return;
    }
  }

  const chatId = message.chat.id;
  user = await reloadUser(user.id);
  const photo = message.photo;

  if (!photo?.length) return;

  if (isAdmin(user) && (await adminHandler.handleAdminPhoto(user, chatId, photo))) {
    return;
  }

  if (await require("./serviceBilling").handleReceiptPhoto(user, chatId, photo)) {
    return;
  }

  if (await orderHandler.handleReceiptPhoto(user, chatId, photo)) {
    return;
  }

  await reply(user, chatId, "عکس دریافت شد ولی در این مرحله نیاز نیست.");
};
