const prisma = require("../database/prisma");
const { getMotherTenantId } = require("../database/prisma");
const { reply, replyPhoto } = require("../bot/messenger");
const bale = require("../bot/bale");
const {
  BTN,
  kb,
  inlineKb,
  productDetailMenu,
  PRODUCT_CATEGORIES,
  productCategoriesMenu,
  subMenuKb,
  mainMenu,
} = require("../keyboards/menus");
const {
  buildCatalogPdf,
  isKeptCatalogPdf,
  rememberCatalogPdf,
  takePreviousCatalogPdf,
} = require("../services/catalogPdf");
const { getUnitPrice, formatPrice, isWholesaleUser } = require("../utils/price");
const { scoreCatalogItem } = require("../utils/smartSearch");
const { isMother } = require("../bot/context");

const PRODUCT_LIST_SELECT = {
  id: true,
  code: true,
  title: true,
  costPrice: true,
  profitPercent: true,
  status: true,
  brand: true,
};

const PRODUCT_DETAIL_SELECT = {
  ...PRODUCT_LIST_SELECT,
  description: true,
  imageUrl: true,
  categoryId: true,
  category: {
    select: { id: true, title: true },
  },
};

function motherCatalogWhere(extra = {}) {
  const motherId = getMotherTenantId();
  const scope = motherId
    ? { OR: [{ tenantId: null }, { tenantId: motherId }] }
    : { tenantId: null };
  return { ...extra, ...scope };
}

function motherCategoryWhere(title) {
  const motherId = getMotherTenantId();
  if (motherId) {
    return { title, OR: [{ tenantId: null }, { tenantId: motherId }] };
  }
  return { title, tenantId: null };
}

async function loadProductByCode(code) {
  if (!code) return null;
  const motherId = getMotherTenantId();
  const where = motherId
    ? { code, OR: [{ tenantId: null }, { tenantId: motherId }] }
    : { code, tenantId: null };

  try {
    return await prisma.product.findFirst({
      where,
      select: PRODUCT_DETAIL_SELECT,
    });
  } catch (err) {
    console.error("PRODUCT LOAD:", err);
  }
  try {
    return await prisma.product.findFirst({
      where,
      select: {
        ...PRODUCT_LIST_SELECT,
        description: true,
        imageUrl: true,
        categoryId: true,
      },
    });
  } catch (err) {
    console.error("PRODUCT LOAD FALLBACK:", err);
    return null;
  }
}

const inlineListIds = new Map();

function productRow(product, wholesale) {
  const price = getUnitPrice(product, wholesale);
  const availability = product.status === "AVAILABLE" ? "🟢" : "🔴";
  let label = `${availability} ${product.title} | ${formatPrice(price)}`;
  if (label.length > 60) label = `${label.slice(0, 59)}…`;
  return [{ text: label, callback_data: `product:${product.code}` }];
}

async function sendProductInlineList(user, chatId, products, header) {
  const wholesale = isWholesaleUser(user);
  const rows = products.map((product) => productRow(product, wholesale));
  const chunkSize = 10;
  const ids = [];
  if (user.lastMessageId) ids.push(user.lastMessageId);
  let lastId = null;

  for (let i = 0; i < rows.length; i += chunkSize) {
    const chunk = rows.slice(i, i + chunkSize);
    const title =
      i === 0
        ? header
        : `ادامه فهرست (${i + 1}–${Math.min(i + chunkSize, rows.length)}):`;
    const inlineResult = await bale.sendKeyboard(
      chatId,
      title,
      inlineKb(chunk)
    );
    if (!inlineResult?.ok) {
      console.error("INLINE PRODUCTS FAILED:", inlineResult);
      await reply(
        user,
        chatId,
        "فهرست محصولات ارسال نشد. لطفاً دوباره تلاش کنید."
      );
      return;
    }
    lastId = inlineResult?.result?.message_id || lastId;
    if (lastId) ids.push(lastId);
  }

  inlineListIds.set(user.id, ids);

  if (lastId) {
    await prisma.user.update({
      where: { id: user.id },
      data: { lastMessageId: lastId },
    });
    user.lastMessageId = lastId;
  }
}

async function clearProductListMessages(user, chatId) {
  const ids = new Set(inlineListIds.get(user.id) || []);
  if (user.lastMessageId) ids.add(user.lastMessageId);
  inlineListIds.delete(user.id);

  for (const id of ids) {
    if (isKeptCatalogPdf(user.id, id)) continue;
    try {
      await bale.deleteMessage(chatId, id);
    } catch (err) {
      console.log("DELETE LIST SKIP:", err.message);
    }
  }

  user.lastMessageId = null;
  if (user?.id) {
    try {
      await prisma.user.update({
        where: { id: user.id },
        data: { lastMessageId: null },
      });
    } catch (err) {
      console.log("CLEAR LAST ID SKIP:", err.message);
    }
  }
}

module.exports = async function productsHandler(user, chatId) {
  await reply(
    user,
    chatId,
    "🛍 دسته‌بندی مورد نظر را انتخاب کنید:",
    productCategoriesMenu()
  );
};

module.exports.clearProductListMessages = clearProductListMessages;
module.exports.loadProductByCode = loadProductByCode;

async function loadTenantCategoryTitles(tenantId) {
  const titles = [];
  const seen = new Set();
  try {
    const cats = await prisma.category.findMany({
      where: { tenantId },
      orderBy: { title: "asc" },
      select: { title: true },
    });
    for (const cat of cats) {
      if (cat.title && !seen.has(cat.title)) {
        seen.add(cat.title);
        titles.push(cat.title);
      }
    }
  } catch (err) {
    console.error("TENANT CATEGORY LIST:", err.message);
  }
  try {
    const products = await prisma.product.findMany({
      where: { tenantId },
      select: { category: { select: { title: true } } },
    });
    for (const product of products) {
      const title = product.category?.title;
      if (title && !seen.has(title)) {
        seen.add(title);
        titles.push(title);
      }
    }
  } catch (err) {
    console.error("TENANT CATEGORY FROM PRODUCTS:", err.message);
  }
  return titles;
}

async function showTenantCategoryKeyboard(user, chatId, categories) {
  await prisma.user.update({
    where: { id: user.id },
    data: { orderStep: "TSC:WAIT" },
  });
  user.orderStep = "TSC:WAIT";
  const rows = categories.map((title) => [{ text: title }]);
  rows.push([{ text: BTN.CART }, { text: BTN.BACK_MAIN }]);
  await reply(user, chatId, "📂 دسته مورد نظر را انتخاب کنید:", kb(rows));
}

module.exports.showTenantProducts = async function showTenantProducts(
  user,
  chatId,
  tenantId,
  categoryTitle
) {
  if (!tenantId) {
    await reply(user, chatId, "فروشگاه شناسایی نشد.");
    return;
  }

  try {
    await require("../services/shopProvision").ensureShopRuntimeTables();
  } catch (err) {
    console.error("TENANT PRODUCTS SCHEMA:", err.message);
  }

  const categories = await loadTenantCategoryTitles(tenantId);
  const chosen =
    categoryTitle && categories.includes(categoryTitle) ? categoryTitle : null;

  if (!chosen) {
    if (!categories.length) {
      await reply(
        user,
        chatId,
        "هنوز دسته‌بندی یا محصولی در این فروشگاه ثبت نشده است.\nکاتالوگ پائورا اینجا نمایش داده نمی‌شود.",
        kb([[{ text: BTN.BACK_MAIN }]])
      );
      return;
    }
    await showTenantCategoryKeyboard(user, chatId, categories);
    return;
  }

  let products = [];
  try {
    products = await prisma.product.findMany({
      where: {
        tenantId,
        status: "AVAILABLE",
        category: { title: chosen },
      },
      orderBy: { title: "asc" },
      select: {
        ...PRODUCT_LIST_SELECT,
        category: { select: { id: true, title: true } },
      },
    });
  } catch (err) {
    console.error("TENANT PRODUCTS:", err);
    try {
      const all = await prisma.product.findMany({
        where: { tenantId, status: "AVAILABLE" },
        orderBy: { title: "asc" },
        select: {
          ...PRODUCT_LIST_SELECT,
          category: { select: { id: true, title: true } },
        },
      });
      products = all.filter((p) => p.category?.title === chosen);
    } catch (err2) {
      console.error("TENANT PRODUCTS FALLBACK:", err2);
      await reply(user, chatId, "خواندن محصولات این فروشگاه ممکن نشد.");
      return;
    }
  }

  await prisma.user.update({
    where: { id: user.id },
    data: { orderStep: null },
  });
  user.orderStep = null;

  if (!products.length) {
    await reply(
      user,
      chatId,
      `📂 ${chosen}\n\nدر این دسته هنوز کالایی ثبت نشده است.`,
      kb([[{ text: BTN.BACK_PRODUCTS }], [{ text: BTN.BACK_MAIN }]])
    );
    return;
  }

  await reply(
    user,
    chatId,
    `🛍 ${chosen}\n${products.length} کالا`,
    kb([[{ text: BTN.BACK_PRODUCTS }], [{ text: BTN.CART }], [{ text: BTN.BACK_MAIN }]])
  );
  await sendProductInlineList(
    user,
    chatId,
    products,
    "روی هر محصول برای جزئیات کلیک کنید:"
  );
};

module.exports.loadTenantProductByCode = async function loadTenantProductByCode(
  code,
  tenantId
) {
  try {
    return await prisma.product.findFirst({
      where: { code, tenantId },
      select: PRODUCT_DETAIL_SELECT,
    });
  } catch (err) {
    console.error("TENANT PRODUCT LOAD:", err);
    return null;
  }
};

module.exports.showSubMenu = async function showSubMenu(user, chatId, categoryBtn) {
  const cat = PRODUCT_CATEGORIES.find((c) => c.btn === categoryBtn);
  if (!cat) {
    await reply(user, chatId, "دسته‌بندی پیدا نشد.");
    return;
  }
  await reply(
    user,
    chatId,
    `${categoryBtn}\n\nیکی از زیر دسته‌ها را انتخاب کنید:`,
    subMenuKb(cat.subMenus)
  );
};

module.exports.showBrandProducts = async function showBrandProducts(
  user,
  chatId,
  categoryBtn,
  brand
) {
  let category;
  let products;
  try {
    category = await prisma.category.findFirst({
      where: motherCategoryWhere(categoryBtn),
    });
    if (!category) {
      await reply(user, chatId, "دسته‌بندی پیدا نشد.");
      return;
    }
    products = await prisma.product.findMany({
      where: motherCatalogWhere({ categoryId: category.id, brand }),
      orderBy: { title: "asc" },
      select: PRODUCT_LIST_SELECT,
    });
  } catch (err) {
    console.error("BRAND PRODUCTS QUERY:", err);
    await reply(
      user,
      chatId,
      "خواندن محصولات از دیتابیس ممکن نشد. لطفاً دوباره تلاش کنید.",
      kb([[{ text: BTN.BACK_PRODUCTS }], [{ text: BTN.BACK_MAIN }]])
    );
    return;
  }

  if (products.length === 0) {
    await reply(
      user,
      chatId,
      `📦 محصولات «${brand}»\nدسته: ${categoryBtn}\n\nمحصولی در این بخش یافت نشد.`,
      subMenuKb(
        (PRODUCT_CATEGORIES.find((c) => c.btn === categoryBtn) || { subMenus: [] }).subMenus
      )
    );
    return;
  }

  await reply(
    user,
    chatId,
    `📂 ${categoryBtn} › ${brand}`,
    kb([
      [{ text: BTN.BACK_PRODUCTS }],
      [{ text: BTN.BACK_MAIN }],
    ])
  );

  await sendProductInlineList(
    user,
    chatId,
    products,
    `${products.length} محصول — روی هر محصول برای جزئیات کلیک کنید:`
  );
};

module.exports.showCategory = async function showCategory(
  user,
  chatId,
  categoryTitle
) {
  let category;
  let products;
  try {
    category = await prisma.category.findFirst({
      where: motherCategoryWhere(categoryTitle),
    });
    if (!category) {
      await reply(user, chatId, "دسته‌بندی پیدا نشد.");
      return;
    }
    products = await prisma.product.findMany({
      where: motherCatalogWhere({ categoryId: category.id }),
      orderBy: { title: "asc" },
      select: PRODUCT_LIST_SELECT,
    });
  } catch (err) {
    console.error("CATEGORY PRODUCTS QUERY:", err);
    await reply(
      user,
      chatId,
      "خواندن محصولات از دیتابیس ممکن نشد. لطفاً دوباره تلاش کنید.",
      kb([[{ text: BTN.BACK_PRODUCTS }], [{ text: BTN.BACK_MAIN }]])
    );
    return;
  }

  if (products.length === 0) {
    await reply(user, chatId, "در این دسته محصولی وجود ندارد.");
    return;
  }

  await reply(
    user,
    chatId,
    `📂 ${category.title}`,
    kb([
      [{ text: BTN.BACK_PRODUCTS }],
      [{ text: BTN.BACK_MAIN }],
    ])
  );

  await sendProductInlineList(
    user,
    chatId,
    products,
    `${products.length} محصول — روی هر محصول برای جزئیات کلیک کنید:`
  );
};

module.exports.showProduct = async function showProduct(
  user,
  chatId,
  product
) {
  const wholesale = isWholesaleUser(user);
  let price = 0;
  try {
    price = getUnitPrice(product, wholesale) || 0;
  } catch (err) {
    console.error("PRODUCT PRICE:", err);
    price = Number(product.costPrice) || 0;
  }
  const status =
    product.status === "AVAILABLE" ? "🟢 موجود" : "🔴 ناموجود";

  try {
    await prisma.user.update({
      where: { id: user.id },
      data: { lastProductCode: product.code },
    });
  } catch (err) {
    console.error("LAST PRODUCT CODE:", err);
  }

  const caption = `📦 ${product.title}

🔖 کد: ${product.code}
🏷 دسته: ${product.category?.title || "—"}
💰 قیمت: ${formatPrice(price)}
${wholesale && isMother() ? "🤝 قیمت همکار" : "🛒 قیمت"}
${status}

📝 ${product.description || "بدون توضیحات"}${
  product.status === "AVAILABLE"
    ? `\n\nبرای انتخاب محصول از دکمه "افزودن به سبد" استفاده نمایید.`
    : "\n\nاین محصول ناموجود است."
}`;

  const menu = productDetailMenu(product);
  const photoCaption =
    caption.length > 1000 ? `${caption.slice(0, 997)}…` : caption;
  const textCaption =
    caption.length > 3500 ? `${caption.slice(0, 3497)}…` : caption;

  await clearProductListMessages(user, chatId);

  if (product.imageUrl) {
    try {
      const photoResult = await replyPhoto(
        user,
        chatId,
        product.imageUrl,
        photoCaption,
        menu
      );
      if (photoResult?.ok || photoResult?.result?.message_id) {
        return;
      }
    } catch (err) {
      console.error("PRODUCT PHOTO:", err);
    }
  }

  try {
    await reply(user, chatId, textCaption, menu);
  } catch (err) {
    console.error("PRODUCT TEXT:", err);
    try {
      await bale.sendMessage(chatId, textCaption);
    } catch (err2) {
      console.error("PRODUCT PLAIN TEXT:", err2);
      throw err2;
    }
  }
};

module.exports.backToProductList = async function backToProductList(user, chatId) {
  if (!user.lastProductCode) {
    await module.exports(user, chatId);
    return;
  }

  const product = await loadProductByCode(user.lastProductCode);

  if (!product?.category?.title || !product.brand) {
    await module.exports(user, chatId);
    return;
  }

  await prisma.user.update({
    where: { id: user.id },
    data: { orderStep: `CAT:${product.category.title}` },
  });
  user.orderStep = `CAT:${product.category.title}`;

  await module.exports.showBrandProducts(
    user,
    chatId,
    product.category.title,
    product.brand
  );
};

const CATALOG_INTRO =
  "تمام محصولات موجود را یک‌جا می‌توانید ببینید.\n\nبرای سفارش سریع، به‌جای استفاده از دکمه‌های منوی محصولات، کد محصول را در قسمت جستجوی سریع وارد کنید و محصول را انتخاب کنید.\n\nارسال فایل ممکن است تا 20 ثانیه زمان ببرد، لطفا صبوری بفرمایید";

const CATALOG_CAPTION =
  "به علت نوسانات شدید ارزی، قبل از سفارش از لیست قیمتی به‌روز استفاده کنید.";

module.exports.showCatalogPdf = async function showCatalogPdf(user, chatId) {
  await reply(user, chatId, CATALOG_INTRO, mainMenu(user));
  try {
    const { buffer } = await buildCatalogPdf(user);
    if (!buffer) {
      await reply(
        user,
        chatId,
        "در حال حاضر محصول موجودی برای نمایش در فایل نیست.",
        mainMenu(user),
        { keepLast: true }
      );
      return;
    }
    const result = await bale.sendDocument(
      chatId,
      buffer,
      CATALOG_CAPTION,
      "pawora-catalog.pdf"
    );
    if (!result?.ok) {
      console.error("CATALOG PDF SEND:", result);
      await reply(
        user,
        chatId,
        "ارسال فایل لیست محصولات ممکن نشد. لطفاً دوباره تلاش کنید.",
        mainMenu(user),
        { keepLast: true }
      );
      return;
    }
    const pdfId = result?.result?.message_id;
    const prevPdfId = takePreviousCatalogPdf(user.id);
    if (prevPdfId && prevPdfId !== pdfId) {
      try {
        await bale.deleteMessage(chatId, prevPdfId);
      } catch (err) {
        console.log("DELETE OLD CATALOG PDF SKIP:", err.message);
      }
    }
    if (pdfId) rememberCatalogPdf(user.id, pdfId);
    if (user.lastMessageId === pdfId) {
      user.lastMessageId = null;
      await prisma.user.update({
        where: { id: user.id },
        data: { lastMessageId: null },
      });
    }
  } catch (err) {
    console.error("CATALOG PDF:", err);
    await reply(
      user,
      chatId,
      "ساخت فایل لیست محصولات ممکن نشد. لطفاً دوباره تلاش کنید.",
      mainMenu(user),
      { keepLast: true }
    );
  }
};

module.exports.handleSearch = async function handleSearch(user, chatId, query) {
  const term = (query || "").trim();
  if (!term) {
    await reply(user, chatId, "⚠️ عبارتی برای جستجو بنویسید.", kb([[{ text: BTN.BACK_MAIN }]]));
    return;
  }

  let products = [];
  try {
    const rows = await prisma.product.findMany({
      where: motherCatalogWhere(),
      select: {
        ...PRODUCT_LIST_SELECT,
        description: true,
        category: { select: { title: true } },
      },
    });
    products = (rows || [])
      .map((row) => ({
        ...row,
        _score: scoreCatalogItem(row, term),
      }))
      .filter((row) => row._score > 0 && row.status === "AVAILABLE")
      .sort((a, b) => b._score - a._score)
      .slice(0, 30);
  } catch (err) {
    console.error("SEARCH PRODUCTS QUERY:", err);
    await reply(
      user,
      chatId,
      "خواندن محصولات از دیتابیس ممکن نشد. لطفاً دوباره تلاش کنید.",
      kb([[{ text: BTN.SEARCH }], [{ text: BTN.BACK_MAIN }]])
    );
    return;
  }

  if (products.length === 0) {
    await reply(
      user,
      chatId,
      `🔍 نتیجه‌ای برای «${term}» یافت نشد.\nنام دیگری امتحان کن.`,
      kb([[{ text: BTN.SEARCH }], [{ text: BTN.BACK_MAIN }]])
    );
    return;
  }

  await reply(
    user,
    chatId,
    `🔍 نتایج جستجو برای «${term}» — ${products.length} محصول:`,
    kb([[{ text: BTN.SEARCH }], [{ text: BTN.BACK_MAIN }]])
  );

  await sendProductInlineList(
    user,
    chatId,
    products,
    "روی هر محصول برای جزئیات کلیک کنید:"
  );
};

module.exports.startAddToCart = async function startAddToCart(user, chatId) {
  if (!user.lastProductCode) {
    await reply(user, chatId, "محصولی انتخاب نشده است.");
    return;
  }

  const product = await loadProductByCode(user.lastProductCode);

  if (!product || product.status !== "AVAILABLE") {
    await reply(user, chatId, "این محصول موجود نیست.");
    return;
  }

  await prisma.user.update({
    where: { id: user.id },
    data: { orderStep: "PRODUCT_QTY" },
  });

  await reply(
    user,
    chatId,
    "🔢 تعداد مورد نظر را وارد کنید (عدد):",
    kb([[{ text: BTN.BACK_MAIN }]])
  );
};

module.exports.addToCartWithQty = async function addToCartWithQty(
  user,
  chatId,
  quantity
) {
  const product = await loadProductByCode(user.lastProductCode);

  if (!product || product.status !== "AVAILABLE") {
    await reply(user, chatId, "محصول موجود نیست.");
    return;
  }

  let cart = await prisma.cart.findUnique({
    where: { userId: user.id },
  });

  if (!cart) {
    cart = await prisma.cart.create({
      data: { userId: user.id },
    });
  }

  const existing = await prisma.cartItem.findFirst({
    where: { cartId: cart.id, productId: product.id },
  });

  if (existing) {
    await prisma.cartItem.update({
      where: { id: existing.id },
      data: { quantity: existing.quantity + quantity },
    });
  } else {
    await prisma.cartItem.create({
      data: {
        cartId: cart.id,
        productId: product.id,
        quantity,
      },
    });
  }

  await prisma.user.update({
    where: { id: user.id },
    data: { orderStep: null },
  });

  await reply(
    user,
    chatId,
    `✅ ${quantity} عدد «${product.title}» به سبد اضافه شد.`,
    kb([
      [{ text: BTN.CART }],
      [{ text: BTN.PRODUCTS }],
      [{ text: BTN.BACK_MAIN }],
    ])
  );
};
