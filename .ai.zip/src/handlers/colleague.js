const prisma = require("../database/prisma");
const { COLLEAGUE_ACCESS_CODE, MANELI_ACCESS_CODE } = require("../config");
const { reply, notify } = require("../bot/messenger");
const bale = require("../bot/bale");
const { BTN, mainMenu, backMain, kb, inlineKb, colleagueGateMenu } = require("../keyboards/menus");
const { setAdminRetailView, setAdminManeliView } = require("../utils/price");
const { isWarehouseOnly, canSwitchModes, staffNotifyIds } = require("../services/user");
const specialServices = require("../services/specialServices");
const {
  provisionShop,
  findOwnedTenant,
  persistColleagueShop,
} = require("../services/shopProvision");
const invoices = require("../services/serviceInvoices");
const serviceBilling = require("./serviceBilling");

const PROFILE_STEPS = [
  "COLLEAGUE_NAME",
  "COLLEAGUE_PHONE",
  "COLLEAGUE_BRAND",
  "COLLEAGUE_SHOP_TYPE",
  "COLLEAGUE_PAGE",
  "COLLEAGUE_ADDRESS",
  "COLLEAGUE_CONFIRM",
];

const MANELI_STEPS = ["MANELI_NAME", "MANELI_PHONE"];

const COLLEAGUE_WELCOME = `✅ حالت خرید همکار فعال شد.

📖 راهنمای بخش همکاران:

در حالت همکار می‌توانید محصولات را با شرایط و قیمت همکاری مشاهده و سفارش خود را ثبت نمایید.

📦 • می‌توانید آدرس مشتری خودتان را مستقیم وارد کنید
• محصول را به صورت دراپ شیپینگ بفروشید
• تسویه با ما به قیمت همکاری انجام می‌شود
• فاکتور برای مشتریان شما ارسال نمی‌شود
•توجه داشته باشید که ثبت سفارش به این شکل است که بعد از انتخاب محصولات مد نظر و صدور پیش فاکتور، کالاهای درخواستی شما با موجودی لحظه ای انبار چک می‌شود و در صورت تایید پیش فاکتور، به شما اطلاع داده می‌شود؛ لازم به ذکر است که پیش فاکتور های تایید شده تا ۳ ساعت قابلیت پرداخت داشته و اعتبار دارند.
شما میتوانید از بخش سفارشات من، پرداخت پیش فاکتور های تایید شده خود را انجام دهید.
پردازش پیش فاکتور ها در روز های کاری تا ساعت ۱۷ انجام می‌گیرد و پیش فاکتور های باقیمانده در روز بعد پردازش خواهند شد .


✅اعتبار ویژه پائورا:

🎁 ۱۰٪ از مبلغ فاکتورهای شما به عنوان اعتبار استفاده از خدمات پلتفرم پائورا به عنوان پاداش همکاری به کیف پول شما بازمی‌گردد
🌟 بابت قدردانی از حسن انتخاب شما، تا ۴۸ ساعت آتی، اعتبار بازگشتی به کیف پول شما (تا سقف ۵۰ میلیون تومان اعتبار) با ضریب ۵۰۰٪ محاسبه می‌شود

🤖 از طریق دکمه «خدمات برنامه‌نویسی» می‌توانید از امکانات و پنل‌ها و خدمات مجاز مجموعه پائورا استفاده نمایید.
💳 قابلیت پرداخت تمامی هزینه‌های خدمات دریافتی همکاران محترم، از طریق اعتبارهای هدیه شما فراهم شده است

PawOra | More Than Care`;

const MANELI_WELCOME = `✅ پنل بازاریابان مانلی فعال شد.

در این حالت محصولات را با قیمت همکاری می‌بینید و سفارش ثبت می‌کنید.
فاکتورهای شما در پنل ادمین مادر، بخش بازاریابان مانلی مدیریت می‌شود.

•توجه داشته باشید که ثبت سفارش به این شکل است که بعد از انتخاب محصولات مد نظر و صدور پیش فاکتور، کالاهای درخواستی شما با موجودی لحظه ای انبار چک می‌شود و در صورت تایید پیش فاکتور، به شما اطلاع داده می‌شود؛ لازم به ذکر است که پیش فاکتور های تایید شده تا ۳ ساعت قابلیت پرداخت داشته و اعتبار دارند.
شما میتوانید از بخش سفارشات من، پرداخت پیش فاکتور های تایید شده خود را انجام دهید.
پردازش پیش فاکتور ها در روز های کاری تا ساعت ۱۷ انجام می‌گیرد و پیش فاکتور های باقیمانده در روز بعد پردازش خواهند شد .

PawOra | More Than Care`;

function colleaguePath(user) {
  const mode = user.tempProvince;
  const path = [
    "COLLEAGUE_NAME",
    "COLLEAGUE_PHONE",
    "COLLEAGUE_BRAND",
    "COLLEAGUE_SHOP_TYPE",
  ];
  if (mode === "PHYSICAL") path.push("COLLEAGUE_ADDRESS");
  else if (mode === "BOTH") path.push("COLLEAGUE_PAGE", "COLLEAGUE_ADDRESS");
  else path.push("COLLEAGUE_PAGE");
  path.push("COLLEAGUE_CONFIRM");
  return path;
}

function withColleagueStep(user, step, body) {
  const path = colleaguePath(user);
  const index = path.indexOf(step);
  const current = index >= 0 ? index + 1 : 1;
  return `مرحله ${current} از ${path.length}\n\n${body}`;
}

function profileNavKb() {
  return kb([[{ text: BTN.BACK_QUESTION }], [{ text: BTN.BACK_MAIN }]]);
}

function shopTypeMenu() {
  return kb([
    [{ text: BTN.SHOP_ONLINE }],
    [{ text: BTN.SHOP_PHYSICAL }],
    [{ text: BTN.SHOP_BOTH }],
    [{ text: BTN.BACK_QUESTION }],
    [{ text: BTN.BACK_MAIN }],
  ]);
}

function confirmMenu() {
  return kb([
    [{ text: BTN.CONFIRM_PROFILE }],
    [{ text: BTN.BACK_QUESTION }],
    [{ text: BTN.BACK_MAIN }],
  ]);
}

function shopModeLabel(mode) {
  if (mode === "ONLINE") return "آنلاین";
  if (mode === "PHYSICAL") return "حضوری";
  if (mode === "BOTH") return "آنلاین و حضوری";
  return "نامشخص";
}

function profileData(user) {
  const mode = user.tempProvince || "";
  return {
    fullName: (user.fullName || "").trim(),
    phone: (user.phone || "").trim(),
    brand: (user.tempDescription || "").trim(),
    mode,
    page: (user.tempCity || "").trim(),
    address: (user.tempAddress || "").trim(),
  };
}

function summaryText(user) {
  const d = profileData(user);
  const lines = [
    "📋 خلاصه اطلاعات همکار",
    "━━━━━━━━━━━━━━━━━━",
    `👤 نام: ${d.fullName || "—"}`,
    `📞 تلفن: ${d.phone || "—"}`,
    `🏷 برند: ${d.brand || "—"}`,
    `🏪 نوع فعالیت: ${shopModeLabel(d.mode)}`,
  ];
  if (d.mode === "ONLINE" || d.mode === "BOTH") {
    lines.push(`🌐 پیج آنلاین: ${d.page || "—"}`);
  }
  if (d.mode === "PHYSICAL" || d.mode === "BOTH") {
    lines.push(`📍 آدرس حضوری: ${d.address || "—"}`);
  }
  lines.push("", "اگر موردی اشتباه است با بازگشت اصلاح کنید.");
  return lines.join("\n");
}

async function persistColleague(user) {
  return persistColleagueShop(user, profileData(user));
}

async function askStep(user, chatId, step) {
  await prisma.user.update({
    where: { id: user.id },
    data: { orderStep: step },
  });
  user.orderStep = step;

  if (step === "COLLEAGUE_NAME") {
    await reply(
      user,
      chatId,
      withColleagueStep(
        user,
        step,
        "برای تکمیل حساب همکار این اطلاعات پت‌شاپ را وارد کنید.\n\n👤 نام و نام خانوادگی:"
      ),
      backMain()
    );
    return;
  }

  if (step === "COLLEAGUE_PHONE") {
    await reply(
      user,
      chatId,
      withColleagueStep(user, step, "📞 شماره تماس:"),
      profileNavKb()
    );
    return;
  }

  if (step === "COLLEAGUE_BRAND") {
    await reply(
      user,
      chatId,
      withColleagueStep(user, step, "🏷 نام برند:"),
      profileNavKb()
    );
    return;
  }

  if (step === "COLLEAGUE_SHOP_TYPE") {
    await reply(
      user,
      chatId,
      withColleagueStep(
        user,
        step,
        "فروشگاه شما تا به امروز به چه شکلی فعالیت داشته است؟"
      ),
      shopTypeMenu()
    );
    return;
  }

  if (step === "COLLEAGUE_PAGE") {
    await reply(
      user,
      chatId,
      withColleagueStep(user, step, "🌐 نام و مشخصات پیج آنلاین را ارسال کنید:"),
      profileNavKb()
    );
    return;
  }

  if (step === "COLLEAGUE_ADDRESS") {
    await reply(
      user,
      chatId,
      withColleagueStep(user, step, "📍 آدرس فروشگاه حضوری را ارسال کنید:"),
      profileNavKb()
    );
    return;
  }

  if (step === "COLLEAGUE_CONFIRM") {
    await reply(
      user,
      chatId,
      withColleagueStep(user, step, summaryText(user)),
      confirmMenu()
    );
  }
}

async function goProfileBack(user, chatId) {
  const step = user.orderStep;
  const mode = user.tempProvince;

  if (step === "COLLEAGUE_PHONE") return askStep(user, chatId, "COLLEAGUE_NAME");
  if (step === "COLLEAGUE_BRAND") return askStep(user, chatId, "COLLEAGUE_PHONE");
  if (step === "COLLEAGUE_SHOP_TYPE") return askStep(user, chatId, "COLLEAGUE_BRAND");
  if (step === "COLLEAGUE_PAGE") return askStep(user, chatId, "COLLEAGUE_SHOP_TYPE");
  if (step === "COLLEAGUE_ADDRESS") {
    if (mode === "BOTH") return askStep(user, chatId, "COLLEAGUE_PAGE");
    return askStep(user, chatId, "COLLEAGUE_SHOP_TYPE");
  }
  if (step === "COLLEAGUE_CONFIRM") {
    if (mode === "PHYSICAL" || mode === "BOTH") {
      return askStep(user, chatId, "COLLEAGUE_ADDRESS");
    }
    return askStep(user, chatId, "COLLEAGUE_PAGE");
  }
  return askStep(user, chatId, "COLLEAGUE_NAME");
}

async function startProfile(user, chatId) {
  const d = profileData(user);
  if (!d.fullName) return askStep(user, chatId, "COLLEAGUE_NAME");
  if (!d.phone) return askStep(user, chatId, "COLLEAGUE_PHONE");
  if (!d.brand) return askStep(user, chatId, "COLLEAGUE_BRAND");
  if (!d.mode) return askStep(user, chatId, "COLLEAGUE_SHOP_TYPE");
  if ((d.mode === "ONLINE" || d.mode === "BOTH") && !d.page) {
    return askStep(user, chatId, "COLLEAGUE_PAGE");
  }
  if ((d.mode === "PHYSICAL" || d.mode === "BOTH") && !d.address) {
    return askStep(user, chatId, "COLLEAGUE_ADDRESS");
  }
  return askStep(user, chatId, "COLLEAGUE_CONFIRM");
}

async function finishProfile(user, chatId) {
  const snapshot = summaryText(user).replace(
    "\n\nاگر موردی اشتباه است با بازگشت اصلاح کنید.",
    ""
  );
  const saved = await persistColleague(user);

  if (!saved.ok) {
    await reply(
      user,
      chatId,
      `اطلاعات روی حساب شما ماند، ولی فروشگاه در دیتابیس ذخیره نشد.

${snapshot}

دوباره «تأیید و ثبت» را بزنید. اگر باز هم همین پیام آمد، روی سرور باید prisma db push اجرا شود.`,
      confirmMenu()
    );
    return;
  }

  await prisma.user.update({
    where: { id: user.id },
    data: {
      orderStep: null,
      tempDescription: null,
      tempAddress: null,
      tempProvince: null,
      tempCity: null,
    },
  });
  user.orderStep = null;

  await reply(
    user,
    chatId,
    `✅ اطلاعات همکار ثبت شد.

${snapshot}

${COLLEAGUE_WELCOME}`,
    mainMenu(user)
  );
}

async function waitSetupApproval(user, chatId, invoice) {
  await prisma.user.update({
    where: { id: user.id },
    data: { orderStep: null, pendingOrderId: null },
  });
  user.orderStep = null;
  user.pendingOrderId = null;
  const code = invoice?.trackingCode ? ` ${invoice.trackingCode}` : "";
  await reply(
    user,
    chatId,
    `فاکتور راه‌اندازی${code} هنوز توسط ادمین پائورا تایید نشده است.

تا تایید پرداخت هزینه راه‌اندازی، امکان ساخت ربات وجود ندارد.
بعد از تایید، دوباره «ساخت ربات فروشگاهی» را بزنید.`,
    mainMenu(user)
  );
}

async function rememberInline(user, result) {
  const msgId = result?.result?.message_id;
  if (!msgId || !user?.id) return;
  await prisma.user.update({
    where: { id: user.id },
    data: { lastMessageId: msgId },
  });
  user.lastMessageId = msgId;
}

async function showProgrammingHub(user, chatId) {
  await prisma.user.update({
    where: { id: user.id },
    data: { orderStep: "PROG_HUB" },
  });
  user.orderStep = "PROG_HUB";
  await reply(
    user,
    chatId,
    "💻 خدمات برنامه‌نویسی\nیکی از گزینه‌ها را انتخاب کنید:",
    kb([[{ text: BTN.BACK_MAIN }]])
  );
  const result = await bale.sendKeyboard(
    chatId,
    "انتخاب کنید:",
    inlineKb([
      [{ text: "🤖 ساخت ربات فروشگاهی", callback_data: "prog:shop" }],
      [{ text: "⭐ استفاده از خدمات ویژه", callback_data: "prog:special" }],
    ])
  );
  await rememberInline(user, result);
}

async function showSpecialServices(user, chatId) {
  const body = await specialServices.getText();
  await prisma.user.update({
    where: { id: user.id },
    data: { orderStep: "PROG_SPECIAL" },
  });
  user.orderStep = "PROG_SPECIAL";
  await reply(user, chatId, body, kb([[{ text: BTN.BACK_MAIN }]]));
  const result = await bale.sendKeyboard(
    chatId,
    "ثبت درخواست:",
    inlineKb([
      [{ text: "📝 ثبت فاکتور جدید", callback_data: "prog:new" }],
      [{ text: "🔙 بازگشت", callback_data: "prog:hub" }],
    ])
  );
  await rememberInline(user, result);
}

async function askSpecialBrief(user, chatId) {
  await prisma.user.update({
    where: { id: user.id },
    data: { orderStep: "PROG_BRIEF" },
  });
  user.orderStep = "PROG_BRIEF";
  await reply(
    user,
    chatId,
    "حدود کار و شرح پروژه را بنویسید:",
    profileNavKb()
  );
}

async function askSpecialPhone(user, chatId) {
  await prisma.user.update({
    where: { id: user.id },
    data: { orderStep: "PROG_PHONE" },
  });
  user.orderStep = "PROG_PHONE";
  await reply(
    user,
    chatId,
    "شماره تماسی که همکاران خدمات بتوانند با شما تماس بگیرند را وارد کنید:",
    profileNavKb()
  );
}

async function gateShopBotCreate(user, chatId, tenant) {
  if (tenant?.bot) {
    await reply(
      user,
      chatId,
      `ربات این فروشگاه قبلاً ثبت شده است${
        tenant.bot.username ? `: @${tenant.bot.username}` : ""
      }.

برای تمدید اشتراک، در همان ربات فروشگاه بزنید:
⚙️ مدیریت فروشگاه → 💳 خرید اشتراک`,
      mainMenu(user)
    );
    return;
  }
  if (!tenant) {
    await startProfile(user, chatId);
    return;
  }
  const initial = await invoices.getInitialInvoice(tenant.id);
  if (initial?.status === "APPROVED") {
    await startBotCreate(user, chatId, tenant.id);
    return;
  }
  if (initial) {
    await waitSetupApproval(user, chatId, initial);
    return;
  }
  await serviceBilling.startInitial(user, chatId, tenant.id);
}

async function startBotCreate(user, chatId, tenantId) {
  await prisma.user.update({
    where: { id: user.id },
    data: {
      orderStep: "BOT_CREATE_TOKEN",
      ...(tenantId ? { pendingOrderId: tenantId } : {}),
    },
  });
  user.orderStep = "BOT_CREATE_TOKEN";
  if (tenantId) user.pendingOrderId = tenantId;

  await reply(
    user,
    chatId,
    `به جهت رعایت قوانین حریم خصوصی و مالکیت قطعی شما همکار محترم در رابطه با فروشگاهتان بهتر است مراحل اولیه ساخت ربات توسط خودتان انجام شود.
مراحل زیر سبب می‌شود که در هر صورتی امنیت فروشگاهتان تضمین باشد:

1. در بله به @botfather بروید
2. دکمه ساخت بازو (ربات) جدید را فشار دهید
3. در صورتی که تا به حال رباتی در بله نداشته باشید نیاز است که خود را با ارائه کد ملی و تاریخ تولد به سطح دو ارتقا دهید
4. برای ربات خود نام و یوزرنیم تنظیم کنید
5. بعد از ساخته شدن ربات دکمه‌ای به نام «رونوشت توکن» می‌بینید، با فشردن این دکمه توکن خود را کپی کرده و در اینجا ارسال نمایید
6. تبریک! ربات شما آماده شد.
از طریق دکمه «تنظیمات فروشگاه» می‌توانید تمام امکانات مورد نیاز ربات خود را به ساده‌ترین شکل ممکن تنظیم کنید.
--لازم به ذکر است در هر لحظه می‌توانید توکن خود را از طریق بات فادر تغییر داده و دسترسی‌ها را قطع کنید

حالا Token را در همین چت ارسال کنید.`,
    backMain()
  );
}

async function registerBot(user, chatId, rawToken) {
  try {
    await reply(
      user,
      chatId,
      "در حال بررسی Token...",
      backMain(),
      { keepLast: true }
    );

    const result = await provisionShop(user, rawToken);

    if (result.code === "NEED_PROFILE") {
      await startProfile(user, chatId);
      return;
    }

    if (result.code === "ALREADY_HAS_BOT") {
      await prisma.user.update({
        where: { id: user.id },
        data: { orderStep: null, pendingOrderId: null },
      });
      const at = result.username ? `: @${result.username}` : "";
      await reply(
        user,
        chatId,
        `ربات این فروشگاه قبلاً ثبت شده است${at}.`,
        mainMenu(user)
      );
      return;
    }

    if (result.code === "NEED_SETUP_INVOICE") {
      const tenant = await findOwnedTenant(user.id);
      await serviceBilling.startInitial(user, chatId, tenant?.id);
      return;
    }

    if (result.code === "NEED_APPROVED_SETUP") {
      await prisma.user.update({
        where: { id: user.id },
        data: { orderStep: null, pendingOrderId: null },
      });
      await waitSetupApproval(user, chatId, {
        trackingCode: result.trackingCode,
      });
      return;
    }

    if (!result.ok) {
      const messages = {
        INVALID_TOKEN: "❌ Token نامعتبر است. لطفاً Token کامل را ارسال کنید.",
        MOTHER_TOKEN:
          "❌ این Token مربوط به ربات مادر است. Token ربات خودتان را ارسال کنید.",
        VALIDATE_FAILED:
          "❌ اعتبارسنجی Token ناموفق بود. Token را بررسی کنید و دوباره ارسال کنید.",
        DUPLICATE_TOKEN: "❌ این Token قبلاً ثبت شده است.",
        SAVE_FAILED:
          "ثبت ربات الان ممکن نشد. بعداً دوباره از دکمه ساخت ربات تلاش کنید.",
      };
      const msg = messages[result.code] || messages.SAVE_FAILED;
      const clearStep = result.code === "SAVE_FAILED";
      if (clearStep) {
        await prisma.user.update({
          where: { id: user.id },
          data: { orderStep: null, pendingOrderId: null },
        });
      }
      await reply(user, chatId, msg, clearStep ? mainMenu(user) : backMain());
      return;
    }

    await prisma.user.update({
      where: { id: user.id },
      data: { orderStep: null, pendingOrderId: null },
    });

    const at = result.username ? `@${result.username}` : "ربات شما";
    await reply(
      user,
      chatId,
      `✅ فروشگاه آماده تحویل است.

🏷 ${result.shopName}
🤖 ${at}

الان در بله ${at} را باز کنید و /start بزنید.
منوی محصولات و راهنما فعال است.
کالا و کارت بانکی را بعداً از داخل ربات خودتان اضافه می‌کنید.`,
      mainMenu(user)
    );
  } catch (err) {
    console.error("REGISTER BOT:", err);
    await reply(
      user,
      chatId,
      "ثبت ربات الان ممکن نشد. Token را دوباره در همین چت بفرستید.",
      backMain()
    );
  }
}

function afterShopType(user) {
  const mode = user.tempProvince;
  if (mode === "PHYSICAL") return "COLLEAGUE_ADDRESS";
  return "COLLEAGUE_PAGE";
}

function afterPage(user) {
  if (user.tempProvince === "BOTH") return "COLLEAGUE_ADDRESS";
  return "COLLEAGUE_CONFIRM";
}

function isColleagueEntryBtn(text) {
  const t = String(text || "").replace(/\s+/g, " ").trim();
  return t === BTN.COLLEAGUE || t === "خرید همکار" || t.endsWith("خرید همکار");
}

function isWholesaleLocked(user) {
  if (canSwitchModes(user)) return false;
  return user.role === "COLLEAGUE" || user.role === "MANELI";
}

function keepsAdminRole(user) {
  return user.role === "ADMIN" || canSwitchModes(user);
}

async function notifyReferrerLostCommission(user) {
  if (!user.referrerId) return;
  try {
    const referrer = await prisma.user.findUnique({
      where: { id: user.referrerId },
      select: { baleId: true, role: true },
    });
    if (!referrer?.baleId) return;
    if (referrer.role === "COLLEAGUE" || referrer.role === "MANELI") return;
    const name = (user.fullName || "").trim() || "یکی از معرفی‌شده‌های شما";
    await notify(
      referrer.baleId,
      `📣 اطلاع بازاریابی

گزینه کمیسیون ۵٪ فقط برای مصرف‌کننده خرد است.

چون «${name}» وارد حالت همکار شده، از این به بعد بابت خریدهای او پورسانتی دریافت نمی‌کنید و این شخص در آمار معرفی‌ها و کیف پول بازاریابی شما دیده نمی‌شود.`
    );
  } catch (err) {
    console.error("REFERRER COLLEAGUE NOTICE SKIP:", err.message);
  }
}

async function rejectModeChange(user, chatId) {
  await reply(
    user,
    chatId,
    "تغییر حالت حساب امکان‌پذیر نیست.",
    mainMenu(user)
  );
}

async function askManeliStep(user, chatId, step) {
  await prisma.user.update({
    where: { id: user.id },
    data: { orderStep: step },
  });
  user.orderStep = step;
  if (step === "MANELI_NAME") {
    await reply(
      user,
      chatId,
      "برای تکمیل حساب بازاریاب مانلی، اطلاعات هویتی خود را وارد کنید.\n\n👤 نام و نام خانوادگی را به صورت کامل بنویسید:",
      backMain()
    );
    return;
  }
  await reply(user, chatId, "📞 شماره تماس:", profileNavKb());
}

async function finishManeliWelcome(user, chatId) {
  await prisma.user.update({
    where: { id: user.id },
    data: { orderStep: null },
  });
  user.orderStep = null;
  await reply(user, chatId, MANELI_WELCOME, mainMenu(user));
}

async function showColleagueGate(user, chatId) {
  await prisma.user.update({
    where: { id: user.id },
    data: { orderStep: "COLLEAGUE_GATE" },
  });
  user.orderStep = "COLLEAGUE_GATE";
  await reply(
    user,
    chatId,
    "ورود به کدام بخش را می‌خواهید؟",
    colleagueGateMenu()
  );
}

async function askColleagueCode(user, chatId) {
  await prisma.user.update({
    where: { id: user.id },
    data: { orderStep: "COLLEAGUE_CODE" },
  });
  user.orderStep = "COLLEAGUE_CODE";
  await reply(
    user,
    chatId,
    `✨ ورود به حالت همکار

با داشتن کد دسترسی همکاری، می‌توانید ربات را به پنل اختصاصی خود تغییر دهید و به امکانات و شرایط ویژه همکاران ما دسترسی پیدا کنید.

🔐 لطفا کد دسترسی خود را وارد نمایید:`,
    backMain()
  );
}

async function askManeliCode(user, chatId) {
  await prisma.user.update({
    where: { id: user.id },
    data: { orderStep: "MANELI_CODE" },
  });
  user.orderStep = "MANELI_CODE";
  await reply(
    user,
    chatId,
    `✨ ورود به پنل بازاریابان مانلی

این بخش برای بازاریابان مجموعه همکار است.
خرید با قیمت همکاری ثبت می‌شود و فاکتورها در پنل ادمین مادر جمع می‌شوند.

🔐 لطفا کد دسترسی بازاریابان مانلی را وارد نمایید:`,
    backMain()
  );
}

module.exports = async function colleagueHandler(user, chatId, text) {
  if (isColleagueEntryBtn(text)) {
    if (user.adminStep === "ADMIN_INV_KIND") return false;
    if (isWholesaleLocked(user)) {
      await rejectModeChange(user, chatId);
      return true;
    }
    await showColleagueGate(user, chatId);
    return true;
  }

  if (text === BTN.ENTER_COLLEAGUE) {
    if (isWholesaleLocked(user)) {
      await rejectModeChange(user, chatId);
      return true;
    }
    await askColleagueCode(user, chatId);
    return true;
  }

  if (text === BTN.ENTER_MANELI) {
    if (isWholesaleLocked(user)) {
      await rejectModeChange(user, chatId);
      return true;
    }
    await askManeliCode(user, chatId);
    return true;
  }

  if (text === BTN.RETAIL_MODE) {
    if (!keepsAdminRole(user)) {
      await reply(
        user,
        chatId,
        "بازگشت به خرید خرد در حالت همکار امکان‌پذیر نیست.",
        mainMenu(user)
      );
      return true;
    }

    setAdminRetailView(user.id, true);
    setAdminManeliView(user.id, false);
    await prisma.user.update({
      where: { id: user.id },
      data: { orderStep: null },
    });
    user.orderStep = null;

    await reply(
      user,
      chatId,
      "✅ حالت تست خرید خرد فعال شد.\nقیمت‌ها مثل یوزر نمایش داده می‌شوند. نقش ادمین تغییر نکرد.",
      mainMenu(user)
    );

    return true;
  }

  if (text === BTN.CREATE_SHOP_BOT) {
    if (isWarehouseOnly(user)) return false;
    if (user.role !== "COLLEAGUE" && user.role !== "ADMIN") return false;
    await showProgrammingHub(user, chatId);
    return true;
  }

  if (!isWarehouseOnly(user) && (await serviceBilling.handleText(user, chatId, text))) {
    return true;
  }

  if (text === BTN.BACK_QUESTION && PROFILE_STEPS.includes(user.orderStep)) {
    await goProfileBack(user, chatId);
    return true;
  }

  if (text === BTN.BACK_QUESTION && user.orderStep === "PROG_PHONE") {
    await askSpecialBrief(user, chatId);
    return true;
  }
  if (text === BTN.BACK_QUESTION && user.orderStep === "PROG_BRIEF") {
    await showSpecialServices(user, chatId);
    return true;
  }

  if (user.orderStep === "PROG_BRIEF") {
    if (Object.values(BTN).includes(text)) return false;
    const brief = text.trim();
    if (!brief) {
      await reply(user, chatId, "شرح پروژه را بنویسید.", profileNavKb());
      return true;
    }
    await prisma.user.update({
      where: { id: user.id },
      data: { tempDescription: brief, orderStep: "PROG_PHONE" },
    });
    user.tempDescription = brief;
    await askSpecialPhone(user, chatId);
    return true;
  }

  if (user.orderStep === "PROG_PHONE") {
    if (Object.values(BTN).includes(text)) return false;
    const phone = text.trim();
    if (!phone) {
      await reply(user, chatId, "شماره تماس را وارد کنید.", profileNavKb());
      return true;
    }
    const tenant = await findOwnedTenant(user.id);
    const invoice = await invoices.createSpecialInvoice({
      userId: user.id,
      tenantId: tenant?.id || null,
      brief: user.tempDescription || "",
      phone,
    });
    await prisma.user.update({
      where: { id: user.id },
      data: { orderStep: null, tempDescription: null },
    });
    user.orderStep = null;
    user.tempDescription = null;
    const code = invoice?.trackingCode ? `\n🔖 ${invoice.trackingCode}` : "";
    await reply(
      user,
      chatId,
      `✅ درخواست خدمات ویژه ثبت شد.${code}\n\nهمکاران ما از بخش خدمات با شما تماس خواهند گرفت.`,
      mainMenu(user)
    );
    if (invoice) {
      const notice = `🆕 فاکتور خدمات ویژه\n🔖 ${invoice.trackingCode}\n👤 ${user.fullName || user.baleId}\n📞 ${phone}`;
      for (const adminId of staffNotifyIds()) {
        try {
          await notify(adminId, notice);
        } catch (err) {
          console.log("SPECIAL INVOICE NOTIFY SKIP:", err.message);
        }
      }
    }
    return true;
  }

  if (text === BTN.BACK_QUESTION && MANELI_STEPS.includes(user.orderStep)) {
    if (user.orderStep === "MANELI_PHONE") {
      await askManeliStep(user, chatId, "MANELI_NAME");
      return true;
    }
    await showColleagueGate(user, chatId);
    return true;
  }

  if (user.orderStep === "MANELI_CODE") {
    if (isWholesaleLocked(user)) {
      await prisma.user.update({
        where: { id: user.id },
        data: { orderStep: null },
      });
      user.orderStep = null;
      await rejectModeChange(user, chatId);
      return true;
    }
    if (!MANELI_ACCESS_CODE || text.trim() !== MANELI_ACCESS_CODE) {
      await reply(
        user,
        chatId,
        "❌ کد دسترسی اشتباه است. دوباره تلاش کنید یا به منوی اصلی برگردید.",
        backMain()
      );
      return true;
    }

    const keepRole = keepsAdminRole(user);
    const roleData = keepRole
      ? { orderStep: null }
      : { role: "MANELI", orderStep: null };
    try {
      await prisma.user.update({
        where: { id: user.id },
        data: roleData,
      });
    } catch (err) {
      console.error("MANELI ROLE SET SKIP:", err.message);
      if (!keepRole) {
        await prisma.$executeRawUnsafe(
          `UPDATE "User" SET role = 'MANELI', "orderStep" = NULL WHERE id = $1`,
          user.id
        );
      } else {
        await prisma.user.update({
          where: { id: user.id },
          data: { orderStep: null },
        });
      }
    }
    if (keepRole) {
      setAdminRetailView(user.id, false);
      setAdminManeliView(user.id, true);
      await finishManeliWelcome(user, chatId);
      return true;
    }
    user.role = "MANELI";
    await askManeliStep(user, chatId, "MANELI_NAME");
    return true;
  }

  if (user.orderStep === "MANELI_NAME") {
    const name = text.trim();
    if (!name) {
      await reply(
        user,
        chatId,
        "لطفاً نام و نام خانوادگی را به صورت کامل وارد کنید.",
        backMain()
      );
      return true;
    }
    await prisma.user.update({
      where: { id: user.id },
      data: { fullName: name },
    });
    user.fullName = name;
    await askManeliStep(user, chatId, "MANELI_PHONE");
    return true;
  }

  if (user.orderStep === "MANELI_PHONE") {
    const phone = text.trim();
    if (!phone) {
      await reply(user, chatId, "لطفاً شماره تماس را وارد کنید.", profileNavKb());
      return true;
    }
    await prisma.user.update({
      where: { id: user.id },
      data: { phone },
    });
    user.phone = phone;
    await finishManeliWelcome(user, chatId);
    return true;
  }

  if (user.orderStep === "COLLEAGUE_CODE") {
    if (isWholesaleLocked(user)) {
      await prisma.user.update({
        where: { id: user.id },
        data: { orderStep: null },
      });
      user.orderStep = null;
      await rejectModeChange(user, chatId);
      return true;
    }
    if (!COLLEAGUE_ACCESS_CODE || text.trim() !== COLLEAGUE_ACCESS_CODE) {
      await reply(
        user,
        chatId,
        "❌ کد دسترسی اشتباه است. دوباره تلاش کنید یا به منوی اصلی برگردید.",
        backMain()
      );
      return true;
    }

    const keepRole = keepsAdminRole(user);
    const roleData = keepRole
      ? { orderStep: null }
      : { role: "COLLEAGUE", orderStep: null };
    await prisma.user.update({
      where: { id: user.id },
      data: roleData,
    });
    if (keepRole) {
      setAdminRetailView(user.id, false);
      setAdminManeliView(user.id, false);
    } else {
      user.role = "COLLEAGUE";
      await notifyReferrerLostCommission(user);
    }

    await require("../services/goldenCampaign")
      .startGoldenPeriod(user.id)
      .catch((err) => {
        console.error("GOLDEN PERIOD START SKIP:", err.message);
      });

    await reply(user, chatId, COLLEAGUE_WELCOME, mainMenu(user));

    if (!keepRole) {
      const tenant = await findOwnedTenant(user.id);
      if (!tenant) await startProfile(user, chatId);
    }

    return true;
  }

  if (user.orderStep === "COLLEAGUE_NAME") {
    const name = text.trim();
    if (!name) {
      await reply(user, chatId, "لطفاً نام و نام خانوادگی را وارد کنید.", backMain());
      return true;
    }
    await prisma.user.update({
      where: { id: user.id },
      data: { fullName: name },
    });
    user.fullName = name;
    await askStep(user, chatId, "COLLEAGUE_PHONE");
    return true;
  }

  if (user.orderStep === "COLLEAGUE_PHONE") {
    const phone = text.trim();
    if (!phone) {
      await reply(user, chatId, "لطفاً شماره تماس را وارد کنید.", profileNavKb());
      return true;
    }
    await prisma.user.update({
      where: { id: user.id },
      data: { phone },
    });
    user.phone = phone;
    await askStep(user, chatId, "COLLEAGUE_BRAND");
    return true;
  }

  if (user.orderStep === "COLLEAGUE_BRAND") {
    const brand = text.trim();
    if (!brand) {
      await reply(user, chatId, "لطفاً نام برند را وارد کنید.", profileNavKb());
      return true;
    }
    await prisma.user.update({
      where: { id: user.id },
      data: { tempDescription: brand },
    });
    user.tempDescription = brand;
    await askStep(user, chatId, "COLLEAGUE_SHOP_TYPE");
    return true;
  }

  if (user.orderStep === "COLLEAGUE_SHOP_TYPE") {
    let mode = null;
    if (text === BTN.SHOP_ONLINE) mode = "ONLINE";
    if (text === BTN.SHOP_PHYSICAL) mode = "PHYSICAL";
    if (text === BTN.SHOP_BOTH) mode = "BOTH";
    if (!mode) {
      await reply(
        user,
        chatId,
        "لطفاً یکی از دکمه‌ها را انتخاب کنید.",
        shopTypeMenu()
      );
      return true;
    }
    await prisma.user.update({
      where: { id: user.id },
      data: { tempProvince: mode },
    });
    user.tempProvince = mode;
    await askStep(user, chatId, afterShopType(user));
    return true;
  }

  if (user.orderStep === "COLLEAGUE_PAGE") {
    const page = text.trim();
    if (!page) {
      await reply(
        user,
        chatId,
        "لطفاً نام و مشخصات پیج را ارسال کنید.",
        profileNavKb()
      );
      return true;
    }
    await prisma.user.update({
      where: { id: user.id },
      data: { tempCity: page },
    });
    user.tempCity = page;
    await askStep(user, chatId, afterPage(user));
    return true;
  }

  if (user.orderStep === "COLLEAGUE_ADDRESS") {
    const address = text.trim();
    if (!address) {
      await reply(
        user,
        chatId,
        "لطفاً آدرس فروشگاه را ارسال کنید.",
        profileNavKb()
      );
      return true;
    }
    await prisma.user.update({
      where: { id: user.id },
      data: { tempAddress: address },
    });
    user.tempAddress = address;
    await askStep(user, chatId, "COLLEAGUE_CONFIRM");
    return true;
  }

  if (user.orderStep === "COLLEAGUE_CONFIRM") {
    if (text === BTN.CONFIRM_PROFILE) {
      await finishProfile(user, chatId);
      return true;
    }
    await reply(
      user,
      chatId,
      "برای ثبت، دکمه تأیید را بزنید یا با بازگشت اطلاعات را اصلاح کنید.",
      confirmMenu()
    );
    return true;
  }

  if (user.orderStep === "BOT_CREATE_TOKEN") {
    await registerBot(user, chatId, text);
    return true;
  }

  if (
    !isWarehouseOnly(user) &&
    (user.role === "COLLEAGUE" || user.role === "ADMIN") &&
    /\d{5,}:[A-Za-z0-9_-]{20,}/.test(text)
  ) {
    await registerBot(user, chatId, text);
    return true;
  }

  return false;
};

module.exports.handleProgrammingCallback = async function handleProgrammingCallback(
  user,
  chatId,
  data
) {
  if (isWarehouseOnly(user)) return false;
  if (user.role !== "COLLEAGUE" && user.role !== "ADMIN") return false;
  if (data === "prog:hub") {
    await showProgrammingHub(user, chatId);
    return true;
  }
  if (data === "prog:shop") {
    const tenant = await findOwnedTenant(user.id);
    await gateShopBotCreate(user, chatId, tenant);
    return true;
  }
  if (data === "prog:special") {
    await showSpecialServices(user, chatId);
    return true;
  }
  if (data === "prog:new") {
    await askSpecialBrief(user, chatId);
    return true;
  }
  return false;
};

module.exports.handleServiceCallback = async function handleServiceCallback(
  user,
  chatId,
  data
) {
  return serviceBilling.handleCallback(user, chatId, data);
};

module.exports.continueAfterInvoice = async function continueAfterInvoice(
  user,
  chatId,
  invoice
) {
  await waitSetupApproval(user, chatId, invoice);
};
