const { DEFAULT_PROFIT_PERCENT } = require("../config");

function calcRetailPrice(product) {
  const profit = Math.floor(
    (product.costPrice * product.profitPercent) / 100
  );
  return product.costPrice + profit;
}

function getUnitPrice(product, isWholesale) {
  return isWholesale ? product.costPrice : calcRetailPrice(product);
}

function formatPrice(amount) {
  return `${Number(amount).toLocaleString("fa-IR")} تومان`;
}

const adminRetailView = new Set();
const adminManeliView = new Set();

function setAdminRetailView(userId, enabled) {
  if (enabled) adminRetailView.add(userId);
  else adminRetailView.delete(userId);
}

function setAdminManeliView(userId, enabled) {
  if (enabled) adminManeliView.add(userId);
  else adminManeliView.delete(userId);
}

function isWholesaleUser(user) {
  if (user.role === "COLLEAGUE" || user.role === "MANELI") return true;
  if (user.role === "ADMIN") return !adminRetailView.has(user.id);
  return false;
}

function isManeliUser(user) {
  return user?.role === "MANELI";
}

function isManeliCheckout(user) {
  if (user?.role === "MANELI") return true;
  return user?.role === "ADMIN" && adminManeliView.has(user.id);
}

function getMinOrderAmount() {
  return 0;
}

module.exports = {
  calcRetailPrice,
  getUnitPrice,
  formatPrice,
  isWholesaleUser,
  isManeliUser,
  isManeliCheckout,
  getMinOrderAmount,
  setAdminRetailView,
  setAdminManeliView,
};
