const { formatPrice } = require("./price");
const { orderStatusLabel, readWholesaleKind, wholesaleKindLabel } = require("./order");
const { SHOP_NAME, BANK_CARD, BANK_IBAN, BANK_HOLDER, BANK_NAME } = require("../config");

function orderKindLabel(order) {
  if (order?.isWholesale || order?.user?.role === "MANELI" || order?.isManeli) {
    const kind =
      order?.isManeli || order?.user?.role === "MANELI"
        ? "maneli"
        : readWholesaleKind(order);
    return `🏷 نوع: ${wholesaleKindLabel(kind)}`;
  }
  return "🏷 نوع: خرید عادی";
}

function buildInvoiceText(order, items, shopName = SHOP_NAME) {
  const title =
    order?.isWholesale && order.status === "WAITING_PAYMENT" && !order.receiptImage
      ? `🧾 پیش‌فاکتور ${shopName}`
      : `🧾 فاکتور ${shopName}`;
  const lines = [
    title,
    `━━━━━━━━━━━━━━━━━━`,
    `🔖 کد پیگیری: ${order.trackingCode}`,
    ...(order?.adminRefNo ? [`🏷️ شماره مرجع: ${order.adminRefNo}`] : []),
    `📊 وضعیت: ${orderStatusLabel(order)}`,
    `👤 ${order.fullName}`,
    `📱 ${order.phone}`,
    `📍 ${order.province}، ${order.city}`,
    `🏠 ${order.address}`,
  ];

  if (order.postalCode) {
    lines.push(`📮 کد پستی: ${order.postalCode}`);
  }

  if (order.description) {
    lines.push(`📝 توضیحات: ${order.description}`);
  }

  lines.push("", "📦 اقلام سفارش:", "");

  for (const item of items) {
    lines.push(
      `• ${item.product.title}`,
      `  کد: ${item.product.code} | تعداد: ${item.quantity}`,
      `  قیمت واحد: ${formatPrice(item.unitPrice)}`,
      `  جمع: ${formatPrice(item.unitPrice * item.quantity)}`,
      ""
    );
  }

  lines.push(
    "━━━━━━━━━━━━━━━━━━",
    `💰 جمع کل: ${formatPrice(order.totalAmount)}`,
    orderKindLabel(order)
  );

  return lines.join("\n");
}

function buildPaymentInfo(bank) {
  const card = bank?.card ?? BANK_CARD;
  const iban = bank?.iban ?? BANK_IBAN;
  const holder = bank?.holder ?? BANK_HOLDER;
  const name = bank?.name ?? BANK_NAME;
  const lines = [
    "💳 اطلاعات پرداخت",
    "━━━━━━━━━━━━━━━━━━",
  ];

  if (card) lines.push(`💳 شماره کارت: ${card}`);
  if (iban) lines.push(`🔢 شماره شبا: ${iban}`);
  if (holder) lines.push(`👤 به نام: ${holder}`);
  if (name) lines.push(`🏦 بانک: ${name}`);

  lines.push(
    "",
    "پس از واریز، از دکمه «📸 ارسال رسید پرداخت» استفاده کنید",
    "و اسکرین‌شات رسید را ارسال نمایید."
  );

  return lines.join("\n");
}

function buildShippingInfo() {
  return [
    "🚚 اطلاعات ارسال",
    "━━━━━━━━━━━━━━━━━━",
    "📍 تهران و کرج:",
    "تحویل یک‌روزه در روزهای کاری",
    "برای سفارش‌های ثبت‌شده قبل از ساعت ۱۶",
    "قابلیت ارسال با اسنپ",
    "",
    "📍 شهرستان:",
    "ارسال با پست پیشتاز",
    "",
    "💰 هزینه ارسال به عهده مشتری است.",
  ].join("\n");
}

function buildTenantShippingInfo(shop) {
  const lines = ["🚚 ارسال سفارش", "━━━━━━━━━━━━━━━━━━"];
  if (shop?.address) lines.push(`📍 ${shop.address}`);
  if (shop?.phone) lines.push(`📞 هماهنگی: ${shop.phone}`);
  lines.push("", "هزینه و نحوه ارسال با همین فروشگاه هماهنگ می‌شود.");
  return lines.join("\n");
}

module.exports = {
  buildInvoiceText,
  orderKindLabel,
  buildPaymentInfo,
  buildShippingInfo,
  buildTenantShippingInfo,
};
